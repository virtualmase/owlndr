# Project TODO

- [x] Configure dark theme colors (arcturian ultraviolet/blue gradient)
- [x] Generate custom app logo
- [x] Set up 4-tab navigation (Home, Explore, Wallet, Profile)
- [x] Add icon mappings for all tabs
- [x] Build Home screen with protocol stats banner
- [x] Build Home screen leaderboard with top 3 podium + ranked list
- [x] Build Explore screen with search and archetype filters
- [x] Build Agent Detail screen with stats grid and price chart
- [x] Build Agent Detail bid/trade section
- [x] Build Wallet screen with connect wallet CTA
- [x] Integrate Base chain wallet connectivity
- [x] Integrate Brave Wallet deep link support
- [x] Show wallet balances (ETH, USDC, BID)
- [x] Build Profile screen with portfolio and watchlist
- [x] Build Settings with theme toggle
- [x] Add haptic feedback on key interactions
- [x] Add press animations on buttons and cards
- [x] Create mock data for agents, tokens, and transactions
- [x] Polish UI and ensure consistent dark theme
- [x] Update color scheme to arcturian ultraviolet/blue gradient
- [x] Rename app to OWLNDR
- [x] Regenerate app logo with new color scheme and branding
- [x] Add Coinbase Wallet as a connection option

## Phase 2 — Live Data & Retention

- [x] Research and integrate CreatorBid API / The Graph subgraph for live data
- [x] Build data service layer (API client, caching, real-time updates)
- [x] Replace mock leaderboard with live agent rankings
- [x] Replace mock protocol stats with live on-chain data
- [x] Add real interactive price charts (candlestick/line) on Agent Detail
- [x] Implement push notifications system (agent alerts, price targets, new launches)
- [x] Build notification preferences screen
- [x] Implement persistent watchlist with AsyncStorage syncing
- [x] Build Conviction Vault staking UI (stake BID, view rewards, claim)
- [x] Add shareable agent cards (deep link + image generation)
- [x] Add referral hooks and airdrop tracking
- [x] Polish Explore → Agent → Bid flow (loading states, error handling, confirmation)
- [x] Add pull-to-refresh on Home and Explore screens
- [x] Add skeleton loading states for all data-dependent screens
- [x] Improve wallet integration with real signing simulation
- [ ] Add onboarding flow for first-time users (deferred to Phase 3)
