/**
 * Notifications Store - Manages notification preferences and local alerts
 */
import AsyncStorage from "@react-native-async-storage/async-storage";
import { useState, useEffect, useCallback } from "react";

const NOTIF_PREFS_KEY = "@owlndr_notif_prefs";
const NOTIF_HISTORY_KEY = "@owlndr_notif_history";

export interface NotificationPreferences {
  priceAlerts: boolean;
  newAgentLaunches: boolean;
  portfolioUpdates: boolean;
  weeklyDigest: boolean;
  priceThreshold: number; // percentage change to trigger alert
}

export interface NotificationItem {
  id: string;
  type: "price_alert" | "new_agent" | "portfolio" | "system";
  title: string;
  body: string;
  timestamp: number;
  read: boolean;
  agentId?: string;
}

const DEFAULT_PREFS: NotificationPreferences = {
  priceAlerts: true,
  newAgentLaunches: true,
  portfolioUpdates: true,
  weeklyDigest: false,
  priceThreshold: 10,
};

export async function getNotificationPrefs(): Promise<NotificationPreferences> {
  try {
    const raw = await AsyncStorage.getItem(NOTIF_PREFS_KEY);
    return raw ? { ...DEFAULT_PREFS, ...JSON.parse(raw) } : DEFAULT_PREFS;
  } catch {
    return DEFAULT_PREFS;
  }
}

export async function saveNotificationPrefs(prefs: NotificationPreferences): Promise<void> {
  await AsyncStorage.setItem(NOTIF_PREFS_KEY, JSON.stringify(prefs));
}

export async function getNotificationHistory(): Promise<NotificationItem[]> {
  try {
    const raw = await AsyncStorage.getItem(NOTIF_HISTORY_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export async function addNotification(notif: Omit<NotificationItem, "id" | "timestamp" | "read">): Promise<void> {
  const history = await getNotificationHistory();
  const newItem: NotificationItem = {
    ...notif,
    id: `notif_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
    timestamp: Date.now(),
    read: false,
  };
  const updated = [newItem, ...history].slice(0, 100); // Keep last 100
  await AsyncStorage.setItem(NOTIF_HISTORY_KEY, JSON.stringify(updated));
}

export async function markNotificationRead(id: string): Promise<void> {
  const history = await getNotificationHistory();
  const updated = history.map((n) => (n.id === id ? { ...n, read: true } : n));
  await AsyncStorage.setItem(NOTIF_HISTORY_KEY, JSON.stringify(updated));
}

export async function clearAllNotifications(): Promise<void> {
  await AsyncStorage.setItem(NOTIF_HISTORY_KEY, JSON.stringify([]));
}

/**
 * Hook for notification preferences
 */
export function useNotificationPrefs() {
  const [prefs, setPrefs] = useState<NotificationPreferences>(DEFAULT_PREFS);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getNotificationPrefs().then((p) => {
      setPrefs(p);
      setLoading(false);
    });
  }, []);

  const updatePrefs = useCallback(async (updates: Partial<NotificationPreferences>) => {
    const newPrefs = { ...prefs, ...updates };
    setPrefs(newPrefs);
    await saveNotificationPrefs(newPrefs);
  }, [prefs]);

  return { prefs, loading, updatePrefs };
}

/**
 * Hook for notification history
 */
export function useNotifications() {
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [loading, setLoading] = useState(true);

  const refresh = useCallback(async () => {
    const history = await getNotificationHistory();
    setNotifications(history);
    setLoading(false);
  }, []);

  useEffect(() => {
    refresh();
  }, [refresh]);

  const markRead = useCallback(async (id: string) => {
    await markNotificationRead(id);
    await refresh();
  }, [refresh]);

  const clearAll = useCallback(async () => {
    await clearAllNotifications();
    setNotifications([]);
  }, []);

  const unreadCount = notifications.filter((n) => !n.read).length;

  return { notifications, loading, unreadCount, markRead, clearAll, refresh };
}
