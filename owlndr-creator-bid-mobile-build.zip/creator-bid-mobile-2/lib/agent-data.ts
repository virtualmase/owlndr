import { type Agent, type AgentArchetype, AGENTS } from "@/lib/mock-data";
import { type AgentLiveData, type TokenPairData } from "@/lib/api";

const LIVE_ARCHETYPES: AgentArchetype[] = [
  "WHALE",
  "SNIPER",
  "TRENDFOLLOWER",
  "FOMOBUYER",
  "WHALE MOMENTUM",
];

export interface DisplayAgent extends Agent {
  source: "mock" | "live";
  symbol: string;
  pairAddress?: string;
  tokenAddress?: string;
  dexId?: string;
  priceUsd?: number;
  priceChange24h?: number;
  liquidity?: number;
  marketCap?: number;
  buys24h?: number;
  sells24h?: number;
}

function buildPriceHistory(price: number, changePct: number): number[] {
  const safePrice = Number.isFinite(price) && price > 0 ? price : 1;
  const start = safePrice / (1 + changePct / 100 || 1);

  return Array.from({ length: 24 }, (_, idx) => {
    const progress = idx / 23;
    const wave = Math.sin(progress * Math.PI * 3) * safePrice * 0.018;
    return Math.max(0.000001, start + (safePrice - start) * progress + wave);
  });
}

export function liveAgentToDisplay(agent: AgentLiveData, rank: number): DisplayAgent {
  const archetype = LIVE_ARCHETYPES[(rank - 1) % LIVE_ARCHETYPES.length];

  return {
    id: agent.pairAddress,
    name: agent.name,
    symbol: agent.symbol,
    archetype,
    winnings: agent.volume24h,
    returnPct: agent.priceChange24h,
    fills: agent.buys24h + agent.sells24h,
    totalVolume: agent.volume24h,
    rank,
    isActive: agent.volume24h > 0 || agent.buys24h + agent.sells24h > 0,
    priceHistory: buildPriceHistory(agent.priceUsd, agent.priceChange24h),
    source: "live",
    pairAddress: agent.pairAddress,
    tokenAddress: agent.tokenAddress,
    dexId: agent.dexId,
    priceUsd: agent.priceUsd,
    priceChange24h: agent.priceChange24h,
    liquidity: agent.liquidity,
    marketCap: agent.marketCap,
    buys24h: agent.buys24h,
    sells24h: agent.sells24h,
  };
}

export function pairToDisplayAgent(pair: TokenPairData): DisplayAgent {
  return liveAgentToDisplay(
    {
      id: pair.pairAddress,
      name: pair.baseToken.name,
      symbol: pair.baseToken.symbol,
      pairAddress: pair.pairAddress,
      tokenAddress: pair.baseToken.address,
      dexId: pair.dexId,
      priceUsd: parseFloat(pair.priceUsd || "0"),
      priceChange24h: pair.priceChange?.h24 ?? 0,
      volume24h: pair.volume?.h24 ?? 0,
      liquidity: pair.liquidity?.usd ?? 0,
      marketCap: pair.marketCap ?? pair.fdv ?? 0,
      buys24h: pair.txns?.h24?.buys ?? 0,
      sells24h: pair.txns?.h24?.sells ?? 0,
    },
    1
  );
}

export function getDisplayAgents(liveAgents?: AgentLiveData[]): DisplayAgent[] {
  if (liveAgents && liveAgents.length > 0) {
    return liveAgents
      .slice()
      .sort((a, b) => b.volume24h - a.volume24h)
      .map((agent, idx) => liveAgentToDisplay(agent, idx + 1));
  }

  return AGENTS.map((agent) => ({
    ...agent,
    source: "mock" as const,
    symbol: agent.name.slice(0, 6).toUpperCase(),
  }));
}

export function getMockDisplayAgent(id?: string): DisplayAgent | undefined {
  const agent = AGENTS.find((item) => item.id === id);
  if (!agent) return undefined;

  return {
    ...agent,
    source: "mock",
    symbol: agent.name.slice(0, 6).toUpperCase(),
  };
}
