export type AgentArchetype = "WHALE" | "SNIPER" | "TRENDFOLLOWER" | "FOMOBUYER" | "CUSTOM" | "WHALE MOMENTUM";

export interface Agent {
  id: string;
  name: string;
  archetype: AgentArchetype;
  winnings: number;
  returnPct: number;
  fills: number;
  totalVolume: number;
  rank: number;
  isActive: boolean;
  priceHistory: number[];
}

export interface ProtocolStats {
  status: string;
  buys: number;
  sells: number;
  volume: number;
  token: string;
  mark: number;
  agents: number;
  updatedAt: string;
}

export interface WalletBalance {
  eth: number;
  usdc: number;
  bid: number;
}

export interface Transaction {
  id: string;
  type: "buy" | "sell";
  agent: string;
  amount: number;
  price: number;
  timestamp: string;
}

// Generate random price history
function generatePriceHistory(basePrice: number, points: number = 24): number[] {
  const history: number[] = [];
  let price = basePrice;
  for (let i = 0; i < points; i++) {
    price += (Math.random() - 0.48) * basePrice * 0.05;
    history.push(Math.max(0.01, price));
  }
  return history;
}

export const AGENTS: Agent[] = [
  {
    id: "1",
    name: "gain-snacher",
    archetype: "WHALE MOMENTUM",
    winnings: 183274.44,
    returnPct: 763.6,
    fills: 17,
    totalVolume: 33922982,
    rank: 1,
    isActive: true,
    priceHistory: generatePriceHistory(1.34),
  },
  {
    id: "2",
    name: "JB",
    archetype: "WHALE",
    winnings: 2764856.70,
    returnPct: 35.9,
    fills: 11,
    totalVolume: 12764857,
    rank: 2,
    isActive: true,
    priceHistory: generatePriceHistory(1.34),
  },
  {
    id: "3",
    name: "818-predator",
    archetype: "TRENDFOLLOWER",
    winnings: 288771.31,
    returnPct: 28.1,
    fills: 2,
    totalVolume: 3713744,
    rank: 3,
    isActive: true,
    priceHistory: generatePriceHistory(1.34),
  },
  {
    id: "4",
    name: "Goliath",
    archetype: "WHALE",
    winnings: 921622.45,
    returnPct: 11.6,
    fills: 12,
    totalVolume: 8500000,
    rank: 4,
    isActive: true,
    priceHistory: generatePriceHistory(1.34),
  },
  {
    id: "5",
    name: "alien",
    archetype: "CUSTOM",
    winnings: 0,
    returnPct: 0,
    fills: 0,
    totalVolume: 0,
    rank: 5,
    isActive: false,
    priceHistory: generatePriceHistory(1.34),
  },
  {
    id: "6",
    name: "Agent Alpha",
    archetype: "WHALE",
    winnings: 0,
    returnPct: 0,
    fills: 0,
    totalVolume: 0,
    rank: 7,
    isActive: false,
    priceHistory: generatePriceHistory(1.34),
  },
  {
    id: "7",
    name: "Stormchaser",
    archetype: "FOMOBUYER",
    winnings: 0,
    returnPct: 0,
    fills: 0,
    totalVolume: 0,
    rank: 8,
    isActive: false,
    priceHistory: generatePriceHistory(1.34),
  },
  {
    id: "8",
    name: "Megatron",
    archetype: "WHALE",
    winnings: 0,
    returnPct: 0,
    fills: 0,
    totalVolume: 0,
    rank: 9,
    isActive: false,
    priceHistory: generatePriceHistory(1.34),
  },
  {
    id: "9",
    name: "Sharky",
    archetype: "SNIPER",
    winnings: 0,
    returnPct: 0,
    fills: 0,
    totalVolume: 0,
    rank: 10,
    isActive: false,
    priceHistory: generatePriceHistory(1.34),
  },
  {
    id: "10",
    name: "Apex",
    archetype: "SNIPER",
    winnings: 0,
    returnPct: 0,
    fills: 0,
    totalVolume: 0,
    rank: 11,
    isActive: false,
    priceHistory: generatePriceHistory(1.34),
  },
  {
    id: "11",
    name: "predator-603Eb4",
    archetype: "TRENDFOLLOWER",
    winnings: -40317.83,
    returnPct: -27.2,
    fills: 2,
    totalVolume: 148000,
    rank: 12,
    isActive: true,
    priceHistory: generatePriceHistory(1.34),
  },
];

export const PROTOCOL_STATS: ProtocolStats = {
  status: "LIVE",
  buys: 104,
  sells: 111,
  volume: 41764590.74,
  token: "MOONSHADOW",
  mark: 1.343098,
  agents: 12,
  updatedAt: new Date().toLocaleTimeString(),
};

export const MOCK_TRANSACTIONS: Transaction[] = [
  { id: "1", type: "buy", agent: "gain-snacher", amount: 5000, price: 1.34, timestamp: "2 min ago" },
  { id: "2", type: "sell", agent: "JB", amount: 12000, price: 1.33, timestamp: "5 min ago" },
  { id: "3", type: "buy", agent: "Goliath", amount: 8500, price: 1.35, timestamp: "8 min ago" },
  { id: "4", type: "buy", agent: "818-predator", amount: 3200, price: 1.32, timestamp: "12 min ago" },
  { id: "5", type: "sell", agent: "gain-snacher", amount: 15000, price: 1.36, timestamp: "15 min ago" },
];

export const ARCHETYPES: AgentArchetype[] = ["WHALE", "SNIPER", "TRENDFOLLOWER", "FOMOBUYER", "CUSTOM", "WHALE MOMENTUM"];

export function getArchetypeColor(archetype: AgentArchetype): string {
  switch (archetype) {
    case "WHALE":
      return "#0052FF";
    case "WHALE MOMENTUM":
      return "#00FF88";
    case "SNIPER":
      return "#FF4444";
    case "TRENDFOLLOWER":
      return "#FFB800";
    case "FOMOBUYER":
      return "#FF6B35";
    case "CUSTOM":
      return "#8B5CF6";
    default:
      return "#6B7280";
  }
}

export function formatCurrency(value: number): string {
  if (Math.abs(value) >= 1000000) {
    return `${(value / 1000000).toFixed(2)}M`;
  }
  if (Math.abs(value) >= 1000) {
    return `${(value / 1000).toFixed(1)}K`;
  }
  return value.toFixed(2);
}

export function formatUSDC(value: number): string {
  return `${formatCurrency(value)} USDC`;
}
