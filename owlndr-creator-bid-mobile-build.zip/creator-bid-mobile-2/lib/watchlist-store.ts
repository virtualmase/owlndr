/**
 * Watchlist Store - Persisted with AsyncStorage
 */
import AsyncStorage from "@react-native-async-storage/async-storage";
import { useState, useEffect, useCallback } from "react";

const WATCHLIST_KEY = "@owlndr_watchlist";

export interface WatchlistItem {
  id: string;
  name: string;
  symbol: string;
  addedAt: number;
}

let listeners: Set<() => void> = new Set();
let watchlistCache: WatchlistItem[] | null = null;

async function loadWatchlist(): Promise<WatchlistItem[]> {
  if (watchlistCache !== null) return watchlistCache;
  try {
    const raw = await AsyncStorage.getItem(WATCHLIST_KEY);
    watchlistCache = raw ? JSON.parse(raw) : [];
    return watchlistCache!;
  } catch {
    watchlistCache = [];
    return [];
  }
}

async function saveWatchlist(items: WatchlistItem[]): Promise<void> {
  watchlistCache = items;
  await AsyncStorage.setItem(WATCHLIST_KEY, JSON.stringify(items));
  listeners.forEach((fn) => fn());
}

export async function addToWatchlist(item: Omit<WatchlistItem, "addedAt">): Promise<void> {
  const list = await loadWatchlist();
  if (list.some((w) => w.id === item.id)) return;
  await saveWatchlist([...list, { ...item, addedAt: Date.now() }]);
}

export async function removeFromWatchlist(id: string): Promise<void> {
  const list = await loadWatchlist();
  await saveWatchlist(list.filter((w) => w.id !== id));
}

export async function isInWatchlist(id: string): Promise<boolean> {
  const list = await loadWatchlist();
  return list.some((w) => w.id === id);
}

/**
 * Hook to use the watchlist with real-time updates
 */
export function useWatchlist() {
  const [items, setItems] = useState<WatchlistItem[]>([]);
  const [loading, setLoading] = useState(true);

  const refresh = useCallback(async () => {
    const list = await loadWatchlist();
    setItems(list);
    setLoading(false);
  }, []);

  useEffect(() => {
    refresh();
    const listener = () => refresh();
    listeners.add(listener);
    return () => {
      listeners.delete(listener);
    };
  }, [refresh]);

  const add = useCallback(async (item: Omit<WatchlistItem, "addedAt">) => {
    await addToWatchlist(item);
  }, []);

  const remove = useCallback(async (id: string) => {
    await removeFromWatchlist(id);
  }, []);

  const isWatched = useCallback(
    (id: string) => items.some((w) => w.id === id),
    [items]
  );

  return { items, loading, add, remove, isWatched, refresh };
}
