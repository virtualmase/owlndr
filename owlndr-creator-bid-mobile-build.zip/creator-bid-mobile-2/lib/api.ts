/**
 * OWLNDR Live Data Service Layer
 * Integrates DexScreener API for real-time BID token data on Base chain
 */

const DEXSCREENER_BASE = "https://api.dexscreener.com";
const BID_PAIR_ADDRESS = "0x74f22a01da78294f8df640c98a414fe209e33f60";
const BID_TOKEN_ADDRESS = "0xa1832f7f4e534ae557f9b5ab76de54b1873e498b";
const CHAIN_ID = "base";

// Types
export interface TokenPairData {
  chainId: string;
  dexId: string;
  url: string;
  pairAddress: string;
  baseToken: {
    address: string;
    name: string;
    symbol: string;
  };
  quoteToken: {
    address: string;
    name: string;
    symbol: string;
  };
  priceNative: string;
  priceUsd: string;
  txns: {
    m5: { buys: number; sells: number };
    h1: { buys: number; sells: number };
    h6: { buys: number; sells: number };
    h24: { buys: number; sells: number };
  };
  volume: {
    h24: number;
    h6: number;
    h1: number;
    m5: number;
  };
  priceChange: {
    h1: number;
    h6: number;
    h24: number;
  };
  liquidity: {
    usd: number;
    base: number;
    quote: number;
  };
  fdv: number;
  marketCap: number;
  pairCreatedAt: number;
  info?: {
    imageUrl?: string;
    header?: string;
    websites?: { url: string; label?: string }[];
    socials?: { url: string; type: string }[];
  };
}

export interface ProtocolLiveStats {
  status: "LIVE" | "OFFLINE";
  priceUsd: number;
  priceChange24h: number;
  volume24h: number;
  liquidity: number;
  marketCap: number;
  fdv: number;
  buys24h: number;
  sells24h: number;
  totalTxns24h: number;
  token: string;
  dex: string;
}

export interface AgentLiveData {
  id: string;
  name: string;
  symbol: string;
  pairAddress: string;
  tokenAddress: string;
  dexId: string;
  priceUsd: number;
  priceChange24h: number;
  volume24h: number;
  liquidity: number;
  marketCap: number;
  buys24h: number;
  sells24h: number;
}

// Simple in-memory cache
const cache: Map<string, { data: any; timestamp: number }> = new Map();
const CACHE_TTL = 30_000; // 30 seconds

function getCached<T>(key: string): T | null {
  const entry = cache.get(key);
  if (entry && Date.now() - entry.timestamp < CACHE_TTL) {
    return entry.data as T;
  }
  return null;
}

function setCache(key: string, data: any): void {
  cache.set(key, { data, timestamp: Date.now() });
}

// API Functions

/**
 * Fetch BID token pair data from DexScreener
 */
export async function fetchBIDPairData(): Promise<TokenPairData | null> {
  const cacheKey = "bid_pair_data";
  const cached = getCached<TokenPairData>(cacheKey);
  if (cached) return cached;

  try {
    const response = await fetch(
      `${DEXSCREENER_BASE}/latest/dex/pairs/${CHAIN_ID}/${BID_PAIR_ADDRESS}`
    );
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const data = await response.json();
    const pair = data.pairs?.[0] ?? null;
    if (pair) setCache(cacheKey, pair);
    return pair;
  } catch (error) {
    console.error("[API] Failed to fetch BID pair data:", error);
    return null;
  }
}

/**
 * Fetch a single Base pair by pair address. Used by live search/detail routes.
 */
export async function fetchPairData(pairAddress: string): Promise<TokenPairData | null> {
  const normalized = pairAddress.trim().toLowerCase();
  if (!normalized || !normalized.startsWith("0x")) return null;

  const cacheKey = `pair_${normalized}`;
  const cached = getCached<TokenPairData>(cacheKey);
  if (cached) return cached;

  try {
    const response = await fetch(
      `${DEXSCREENER_BASE}/latest/dex/pairs/${CHAIN_ID}/${normalized}`
    );
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const data = await response.json();
    const pair = data.pairs?.[0] ?? null;
    if (pair) setCache(cacheKey, pair);
    return pair;
  } catch (error) {
    console.error("[API] Pair fetch failed:", error);
    return null;
  }
}

/**
 * Get live protocol stats from DexScreener data
 */
export async function fetchProtocolStats(): Promise<ProtocolLiveStats | null> {
  const pair = await fetchBIDPairData();
  if (!pair) return null;

  return {
    status: "LIVE",
    priceUsd: parseFloat(pair.priceUsd),
    priceChange24h: pair.priceChange.h24,
    volume24h: pair.volume.h24,
    liquidity: pair.liquidity.usd,
    marketCap: pair.marketCap,
    fdv: pair.fdv,
    buys24h: pair.txns.h24.buys,
    sells24h: pair.txns.h24.sells,
    totalTxns24h: pair.txns.h24.buys + pair.txns.h24.sells,
    token: pair.baseToken.symbol,
    dex: pair.dexId,
  };
}

/**
 * Search for token pairs on Base chain
 */
export async function searchTokenPairs(query: string): Promise<TokenPairData[]> {
  const cacheKey = `search_${query}`;
  const cached = getCached<TokenPairData[]>(cacheKey);
  if (cached) return cached;

  try {
    const response = await fetch(
      `${DEXSCREENER_BASE}/latest/dex/search?q=${encodeURIComponent(query)}`
    );
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const data = await response.json();
    const pairs = (data.pairs ?? []).filter(
      (p: TokenPairData) => p.chainId === "base"
    );
    setCache(cacheKey, pairs);
    return pairs;
  } catch (error) {
    console.error("[API] Search failed:", error);
    return [];
  }
}

/**
 * Get pairs for a specific token address on Base
 */
export async function fetchTokenPairs(tokenAddress: string): Promise<TokenPairData[]> {
  const cacheKey = `token_${tokenAddress}`;
  const cached = getCached<TokenPairData[]>(cacheKey);
  if (cached) return cached;

  try {
    const response = await fetch(
      `${DEXSCREENER_BASE}/latest/dex/tokens/${tokenAddress}`
    );
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const data = await response.json();
    const pairs = (data.pairs ?? []).filter(
      (p: TokenPairData) => p.chainId === "base"
    );
    setCache(cacheKey, pairs);
    return pairs;
  } catch (error) {
    console.error("[API] Token pairs fetch failed:", error);
    return [];
  }
}

/**
 * Fetch multiple agent tokens data (simulated from DexScreener search)
 * In production, this would query CreatorBid's own API for agent-specific data
 */
export async function fetchAgentTokens(): Promise<AgentLiveData[]> {
  const cacheKey = "agent_tokens";
  const cached = getCached<AgentLiveData[]>(cacheKey);
  if (cached) return cached;

  try {
    // Search for CreatorBid-related tokens on Base
    const response = await fetch(
      `${DEXSCREENER_BASE}/latest/dex/search?q=CreatorBid`
    );
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const data = await response.json();
    const basePairs = (data.pairs ?? [])
      .filter((p: TokenPairData) => p.chainId === "base")
      .slice(0, 20);

    const agents: AgentLiveData[] = basePairs.map((pair: TokenPairData) => ({
      id: pair.pairAddress,
      name: pair.baseToken.name,
      symbol: pair.baseToken.symbol,
      pairAddress: pair.pairAddress,
      tokenAddress: pair.baseToken.address,
      dexId: pair.dexId,
      priceUsd: parseFloat(pair.priceUsd || "0"),
      priceChange24h: pair.priceChange?.h24 ?? 0,
      volume24h: pair.volume?.h24 ?? 0,
      liquidity: pair.liquidity?.usd ?? 0,
      marketCap: pair.marketCap ?? 0,
      buys24h: pair.txns?.h24?.buys ?? 0,
      sells24h: pair.txns?.h24?.sells ?? 0,
    }));

    setCache(cacheKey, agents);
    return agents;
  } catch (error) {
    console.error("[API] Agent tokens fetch failed:", error);
    return [];
  }
}

// Utility formatters
export function formatPrice(price: number): string {
  if (price < 0.0001) return `$${price.toFixed(8)}`;
  if (price < 0.01) return `$${price.toFixed(6)}`;
  if (price < 1) return `$${price.toFixed(4)}`;
  if (price < 100) return `$${price.toFixed(2)}`;
  return `$${price.toLocaleString(undefined, { maximumFractionDigits: 2 })}`;
}

export function formatVolume(vol: number): string {
  if (vol >= 1_000_000) return `$${(vol / 1_000_000).toFixed(2)}M`;
  if (vol >= 1_000) return `$${(vol / 1_000).toFixed(1)}K`;
  return `$${vol.toFixed(0)}`;
}

export function formatPriceChange(change: number): string {
  const sign = change >= 0 ? "+" : "";
  return `${sign}${change.toFixed(2)}%`;
}
