import { describe, it, expect } from "vitest";
import {
  AGENTS,
  PROTOCOL_STATS,
  MOCK_TRANSACTIONS,
  ARCHETYPES,
  getArchetypeColor,
  formatCurrency,
  formatUSDC,
} from "../lib/mock-data";

describe("Mock Data", () => {
  it("should have at least 10 agents", () => {
    expect(AGENTS.length).toBeGreaterThanOrEqual(10);
  });

  it("should have agents with required fields", () => {
    for (const agent of AGENTS) {
      expect(agent.id).toBeDefined();
      expect(agent.name).toBeTruthy();
      expect(agent.archetype).toBeTruthy();
      expect(typeof agent.winnings).toBe("number");
      expect(typeof agent.returnPct).toBe("number");
      expect(typeof agent.fills).toBe("number");
      expect(typeof agent.rank).toBe("number");
      expect(Array.isArray(agent.priceHistory)).toBe(true);
      expect(agent.priceHistory.length).toBeGreaterThan(0);
    }
  });

  it("should have protocol stats with all fields", () => {
    expect(PROTOCOL_STATS.status).toBe("LIVE");
    expect(PROTOCOL_STATS.buys).toBeGreaterThan(0);
    expect(PROTOCOL_STATS.sells).toBeGreaterThan(0);
    expect(PROTOCOL_STATS.volume).toBeGreaterThan(0);
    expect(PROTOCOL_STATS.token).toBe("MOONSHADOW");
    expect(PROTOCOL_STATS.mark).toBeGreaterThan(0);
    expect(PROTOCOL_STATS.agents).toBeGreaterThan(0);
  });

  it("should have mock transactions", () => {
    expect(MOCK_TRANSACTIONS.length).toBeGreaterThan(0);
    for (const tx of MOCK_TRANSACTIONS) {
      expect(["buy", "sell"]).toContain(tx.type);
      expect(tx.amount).toBeGreaterThan(0);
      expect(tx.agent).toBeTruthy();
    }
  });

  it("should have all archetypes defined", () => {
    expect(ARCHETYPES).toContain("WHALE");
    expect(ARCHETYPES).toContain("SNIPER");
    expect(ARCHETYPES).toContain("TRENDFOLLOWER");
    expect(ARCHETYPES).toContain("FOMOBUYER");
    expect(ARCHETYPES).toContain("CUSTOM");
    expect(ARCHETYPES).toContain("WHALE MOMENTUM");
  });
});

describe("getArchetypeColor", () => {
  it("should return a color string for each archetype", () => {
    for (const arch of ARCHETYPES) {
      const color = getArchetypeColor(arch);
      expect(color).toMatch(/^#[0-9A-Fa-f]{6}$/);
    }
  });

  it("should return specific colors for known archetypes", () => {
    expect(getArchetypeColor("WHALE")).toBe("#0052FF");
    expect(getArchetypeColor("WHALE MOMENTUM")).toBe("#00FF88");
    expect(getArchetypeColor("SNIPER")).toBe("#FF4444");
    expect(getArchetypeColor("TRENDFOLLOWER")).toBe("#FFB800");
    expect(getArchetypeColor("FOMOBUYER")).toBe("#FF6B35");
    expect(getArchetypeColor("CUSTOM")).toBe("#8B5CF6");
  });
});

describe("formatCurrency", () => {
  it("should format millions correctly", () => {
    expect(formatCurrency(1500000)).toBe("1.50M");
    expect(formatCurrency(33922982)).toBe("33.92M");
  });

  it("should format thousands correctly", () => {
    expect(formatCurrency(5000)).toBe("5.0K");
    expect(formatCurrency(183274.44)).toBe("183.3K");
  });

  it("should format small numbers correctly", () => {
    expect(formatCurrency(42.5)).toBe("42.50");
    expect(formatCurrency(0)).toBe("0.00");
  });

  it("should handle negative values", () => {
    expect(formatCurrency(-40317.83)).toBe("-40.3K");
    expect(formatCurrency(-1500000)).toBe("-1.50M");
  });
});

describe("formatUSDC", () => {
  it("should append USDC suffix", () => {
    expect(formatUSDC(5000)).toBe("5.0K USDC");
    expect(formatUSDC(1500000)).toBe("1.50M USDC");
    expect(formatUSDC(42.5)).toBe("42.50 USDC");
  });
});
