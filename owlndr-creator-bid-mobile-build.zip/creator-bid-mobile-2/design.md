# CreatorBid Mobile — Interface Design

## Brand & Color Palette

The app adopts a **dark futuristic** aesthetic inspired by the alpha.creator.bid web platform, with neon green accents and deep black backgrounds — evoking a crypto trading terminal feel.

| Token | Light | Dark (Primary) |
|-------|-------|-----------------|
| `primary` | `#00FF88` | `#00FF88` (neon green) |
| `background` | `#0A0A0F` | `#0A0A0F` (deep black) |
| `surface` | `#13131A` | `#13131A` (card dark) |
| `foreground` | `#FFFFFF` | `#FFFFFF` (white text) |
| `muted` | `#6B7280` | `#6B7280` (gray text) |
| `border` | `#1F1F2E` | `#1F1F2E` (subtle border) |
| `success` | `#00FF88` | `#00FF88` (green) |
| `warning` | `#FFB800` | `#FFB800` (amber) |
| `error` | `#FF4444` | `#FF4444` (red) |

Additional accent colors:
- **Gold/1st place**: `#FFD700`
- **Silver/2nd place**: `#C0C0C0`
- **Bronze/3rd place**: `#CD7F32`
- **Brave accent**: `#FB542B` (Brave orange, used for Brave Wallet CTA)
- **Base blue**: `#0052FF` (Coinbase Base chain brand color)

## Screen List

### Tab Bar (4 tabs)
1. **Home** — Agent leaderboard, live protocol stats, featured token
2. **Explore** — Browse/search all agents, filter by archetype, trending
3. **Wallet** — Base chain wallet, balances, transaction history, Brave Wallet connect
4. **Profile** — User settings, portfolio, watchlist

### Detail Screens (pushed from tabs)
5. **Agent Detail** — Full agent stats, price chart, bid/trade actions, archetype badge
6. **Token Detail** — Token info, bonding curve, DEX links
7. **Settings** — Theme, notifications, wallet management

## Screen Designs

### 1. Home Screen
- **Top bar**: "CreatorBid" logo + live update timestamp
- **Protocol Stats Banner**: Horizontal scrollable row showing Status, Buys, Sells, Volume, Token name, Mark price
- **Featured Token Card**: Large card showing current token (e.g., MOONSHADOW) with mini price chart
- **Leaderboard Section**:
  - Top 3 podium cards (1st gold, 2nd silver, 3rd bronze) with agent name, archetype badge, winnings, return %
  - Remaining agents in a ranked FlatList with columns: Rank, Name, Archetype, Winnings, Return %, Fills
  - Each row tappable → Agent Detail

### 2. Explore Screen
- **Search bar** at top with placeholder "Search agents..."
- **Filter chips**: All, Whale, Sniper, TrendFollower, FomoBuyer, Custom
- **Agent grid/list**: Cards showing agent name, archetype icon, winnings, return %
- **Trending section**: Agents with highest recent volume
- Tap any agent → Agent Detail

### 3. Wallet Screen
- **Connect Wallet CTA** (if not connected): Large button with Brave Wallet icon + "Connect via Brave" and generic WalletConnect option
- **Connected state**:
  - Wallet address (truncated) with copy button
  - Network badge: "Base" with blue icon
  - Balance card: ETH balance, USDC balance, BID token balance
  - Recent transactions list
  - "Disconnect" option
- **Base chain info**: Network name, chain ID, block explorer link

### 4. Profile Screen
- **Avatar/address** section at top
- **Portfolio summary**: Total value, P&L
- **Watchlist**: Saved agents with quick stats
- **Settings links**: Theme toggle, notifications, about

### 5. Agent Detail Screen (Modal/Push)
- **Header**: Agent name + archetype badge + rank
- **Price chart**: Line chart (1S/1M toggle) showing agent key price
- **Stats grid**: Winnings, Return %, Fills, Total Volume
- **Bid/Trade section**: Buy/Sell buttons with amount input
- **Activity feed**: Recent trades for this agent

### 6. Token Detail Screen
- **Token header**: Name, symbol, current price
- **Bonding curve visualization**
- **Market stats**: Market cap, volume, holders
- **DEX link**: Open on Uniswap (Base)

## Key User Flows

### Flow 1: Browse Leaderboard → View Agent
1. User opens app → Home tab loads with leaderboard
2. User sees top 3 agents in podium cards
3. User taps an agent row → Agent Detail screen slides in
4. User views chart, stats, and can place a bid

### Flow 2: Connect Wallet
1. User taps Wallet tab → sees "Connect Wallet" screen
2. User taps "Connect via Brave Wallet" → opens Brave Wallet deep link / WalletConnect
3. Wallet connects → shows balances on Base chain
4. User can now trade/bid from Agent Detail screens

### Flow 3: Search & Discover Agents
1. User taps Explore tab
2. Types agent name in search bar
3. Filters by archetype (e.g., "Whale")
4. Taps agent card → Agent Detail

### Flow 4: Place a Bid/Trade
1. From Agent Detail, user taps "Buy" or "Sell"
2. Enters amount in USDC
3. Confirms transaction → wallet signs
4. Success feedback with haptic + animation

## Typography
- **Headlines**: System bold, 28-32pt
- **Body**: System regular, 16pt
- **Captions/Labels**: System medium, 12-14pt
- **Monospace numbers**: For prices, addresses, stats

## Layout Principles
- Dark-first design (force dark mode for crypto aesthetic)
- Cards with subtle borders and surface backgrounds
- Neon green for positive values, red for negative
- Compact information density (trading terminal feel)
- One-handed reachability: primary actions in bottom half
