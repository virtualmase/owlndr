# API Research - Phase 2

## DexScreener API (Free, No API Key)
Base URL: `https://api.dexscreener.com`

### Key Endpoints:
1. **GET /latest/dex/pairs/{chainId}/{pairId}** - Get pair data (300 req/min)
   - BID/WETH pair on Base: `base/0x74f22a01da78294f8df640c98a414fe209e33f60`
   - Returns: price, volume, txns, liquidity, fdv, marketCap, priceChange

2. **GET /latest/dex/tokens/{tokenAddresses}** - Get pairs by token address (300 req/min)
   - BID token: `0xa1832f7f4e534ae557f9b5ab76de54b1873e498b`

3. **GET /latest/dex/search?q={query}** - Search pairs (300 req/min)

4. **GET /token-profiles/latest/v1** - Latest token profiles (60 req/min)

5. **GET /token-boosts/top/v1** - Most boosted tokens (60 req/min)

## CreatorBid Contract Addresses (Base Chain)
- BID Token: `0xa1832f7f4e534ae557f9b5ab76de54b1873e498b`
- BID/WETH Pair (Aerodrome): `0x74f22a01da78294f8df640c98a414fe209e33f60`
- WETH (Base): `0x4200000000000000000000000000000000000006`

## CoinGecko MCP (Available)
- Can use coingecko MCP server for additional market data
- Real-time prices, market caps, trending tokens

## Data Strategy
- Use DexScreener API for BID token price, volume, liquidity (free, no key)
- Use CoinGecko MCP for broader market data
- Use alpha.creator.bid for agent-specific data (scrape/API if available)
- Cache data locally with TanStack Query (5-min stale time)
