import { Text, View, Pressable, ScrollView, TextInput, Alert, Share, ActivityIndicator } from "react-native";
import { useLocalSearchParams, useRouter } from "expo-router";
import { useMemo, useState, useEffect } from "react";
import { ScreenContainer } from "@/components/screen-container";
import { getArchetypeColor, formatUSDC, formatCurrency } from "@/lib/mock-data";
import { PriceChart } from "@/components/price-chart";
import { useWatchlist } from "@/lib/watchlist-store";
import { getMockDisplayAgent, pairToDisplayAgent } from "@/lib/agent-data";
import { formatVolume } from "@/lib/api";
import { usePairData } from "@/hooks/use-live-data";
import { StyleSheet, Platform } from "react-native";
import * as Haptics from "expo-haptics";

export default function AgentDetailScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  const mockAgent = getMockDisplayAgent(id);
  const shouldFetchLivePair = !mockAgent && !!id?.startsWith("0x");
  const { data: livePair, isLoading: liveLoading } = usePairData(id ?? "", shouldFetchLivePair);
  const agent = useMemo(() => mockAgent ?? (livePair ? pairToDisplayAgent(livePair) : undefined), [livePair, mockAgent]);
  const [tradeAmount, setTradeAmount] = useState("");
  const [tradeType, setTradeType] = useState<"buy" | "sell">("buy");
  const [stakeAmount, setStakeAmount] = useState("");
  const { isWatched, add, remove } = useWatchlist();
  const [watched, setWatched] = useState(false);

  useEffect(() => {
    if (agent) {
      setWatched(isWatched(agent.id));
    }
  }, [agent, isWatched]);

  if (liveLoading) {
    return (
      <ScreenContainer>
        <View style={styles.notFound}>
          <ActivityIndicator size="large" color="#7B2FFF" />
          <Text style={styles.loadingText}>Loading live Base market...</Text>
        </View>
      </ScreenContainer>
    );
  }

  if (!agent) {
    return (
      <ScreenContainer>
        <View style={styles.notFound}>
          <Text style={styles.notFoundText}>Agent not found</Text>
          <Pressable onPress={() => router.back()} style={({ pressed }) => [styles.backBtn, pressed && { opacity: 0.7 }]}>
            <Text style={styles.backBtnText}>Go Back</Text>
          </Pressable>
        </View>
      </ScreenContainer>
    );
  }

  const archetypeColor = getArchetypeColor(agent.archetype);
  const currentPrice = agent.priceHistory[agent.priceHistory.length - 1] ?? 0;
  const amount = parseFloat(tradeAmount);
  const hasValidAmount = Number.isFinite(amount) && amount > 0;
  const tradingFee = hasValidAmount ? amount * 0.01 : 0;
  const estimatedKeys = hasValidAmount && currentPrice > 0 ? amount / currentPrice : 0;
  const routeLabel = agent.source === "live" ? `${agent.dexId?.toUpperCase() ?? "DEX"} on Base` : "CreatorBid on Base";

  const handleTrade = () => {
    if (Platform.OS !== "web") {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    }
    if (!hasValidAmount) {
      Alert.alert("Invalid Amount", "Please enter a valid trade amount.");
      return;
    }
    Alert.alert(
      "Order Prepared",
      `${tradeType === "buy" ? "Buy" : "Sell"} ${formatCurrency(amount)} USDC of ${agent.name} keys.\n\nEstimated keys: ${estimatedKeys.toFixed(4)}\nRoute: ${routeLabel}\n\nWallet signing is simulated in this build.`,
      [{ text: "OK" }]
    );
    setTradeAmount("");
  };

  const handleStake = () => {
    if (Platform.OS !== "web") {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    }
    const amount = parseFloat(stakeAmount);
    if (!amount || amount <= 0) {
      Alert.alert("Invalid Amount", "Please enter a valid stake amount.");
      return;
    }
    Alert.alert(
      "Staked Successfully",
      `Staked ${amount} BID in ${agent.name} Conviction Vault.\nEstimated APY: 12.4%`,
      [{ text: "OK" }]
    );
    setStakeAmount("");
  };

  const handleWatchlist = async () => {
    if (Platform.OS !== "web") {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
    if (watched) {
      await remove(agent.id);
      setWatched(false);
    } else {
      await add({ id: agent.id, name: agent.name, symbol: agent.name.slice(0, 4).toUpperCase() });
      setWatched(true);
    }
  };

  const handleShare = async () => {
    if (Platform.OS !== "web") {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
    try {
      await Share.share({
        message: `Check out ${agent.name} on OWLNDR!\n\nRank #${agent.rank} | ${agent.archetype}\nReturn: ${agent.returnPct > 0 ? "+" : ""}${agent.returnPct}%\nVolume: ${formatUSDC(agent.totalVolume)}\n\nhttps://alpha.creator.bid/agent/${agent.id}`,
        title: `${agent.name} - OWLNDR Agent`,
      });
    } catch (error) {
      // User cancelled share
    }
  };

  return (
    <ScreenContainer>
      <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
        {/* Back Button + Actions */}
        <View style={styles.topBar}>
          <Pressable onPress={() => router.back()} style={({ pressed }) => [styles.backRow, pressed && { opacity: 0.7 }]}>
            <Text style={styles.backArrow}>←</Text>
            <Text style={styles.backLabel}>Back</Text>
          </Pressable>
          <View style={styles.topActions}>
            <Pressable onPress={handleWatchlist} style={({ pressed }) => [styles.actionBtn, pressed && { opacity: 0.7 }]}>
              <Text style={styles.actionIcon}>{watched ? "★" : "☆"}</Text>
            </Pressable>
            <Pressable onPress={handleShare} style={({ pressed }) => [styles.actionBtn, pressed && { opacity: 0.7 }]}>
              <Text style={styles.actionIcon}>↗</Text>
            </Pressable>
          </View>
        </View>

        {/* Agent Header */}
        <View style={styles.agentHeader}>
          <View style={styles.agentHeaderLeft}>
            <Text style={styles.agentName}>{agent.name}</Text>
            <Text style={styles.agentSymbol}>{agent.symbol}</Text>
            <View style={[styles.archetypeBadge, { backgroundColor: archetypeColor + "22" }]}>
              <Text style={[styles.archetypeText, { color: archetypeColor }]}>{agent.archetype}</Text>
            </View>
          </View>
          <View style={styles.rankCircle}>
            <Text style={styles.rankText}>#{agent.rank}</Text>
          </View>
        </View>

        {/* Interactive Price Chart */}
        <View style={styles.chartSection}>
          <PriceChart
            data={agent.priceHistory}
            color={archetypeColor}
            height={200}
            showTimeframes={true}
            currentPrice={currentPrice}
            priceChange={agent.returnPct}
          />
        </View>

        {/* Stats Grid */}
        <View style={styles.statsGrid}>
          <View style={styles.statCard}>
            <Text style={styles.statLabel}>WINNINGS</Text>
            <Text style={[styles.statValue, agent.winnings >= 0 ? styles.positive : styles.negative]}>
              {agent.source === "live" ? formatVolume(agent.totalVolume) : formatUSDC(agent.winnings)}
            </Text>
          </View>
          <View style={styles.statCard}>
            <Text style={styles.statLabel}>RETURN</Text>
            <Text style={[styles.statValue, agent.returnPct >= 0 ? styles.positive : styles.negative]}>
              {agent.returnPct > 0 ? "+" : ""}{agent.returnPct}%
            </Text>
          </View>
          <View style={styles.statCard}>
            <Text style={styles.statLabel}>FILLS</Text>
            <Text style={styles.statValueMuted}>{agent.fills}</Text>
          </View>
          <View style={styles.statCard}>
            <Text style={styles.statLabel}>VOLUME</Text>
            <Text style={styles.statValueMuted}>{formatCurrency(agent.totalVolume)}</Text>
          </View>
        </View>

        {/* Trade Section */}
        <View style={styles.tradeSection}>
          <Text style={styles.tradeSectionTitle}>Trade Agent Keys</Text>
          <Text style={styles.tradeSectionHint}>
            Prepare a Base order for {agent.symbol}. Connect wallet signing in Phase 3 to submit onchain.
          </Text>

          {/* Buy/Sell Toggle */}
          <View style={styles.tradeToggle}>
            <Pressable
              onPress={() => setTradeType("buy")}
              style={[styles.toggleBtn, tradeType === "buy" && styles.toggleBtnBuy]}
            >
              <Text style={[styles.toggleText, tradeType === "buy" && styles.toggleTextActive]}>BUY</Text>
            </Pressable>
            <Pressable
              onPress={() => setTradeType("sell")}
              style={[styles.toggleBtn, tradeType === "sell" && styles.toggleBtnSell]}
            >
              <Text style={[styles.toggleText, tradeType === "sell" && styles.toggleTextActive]}>SELL</Text>
            </Pressable>
          </View>

          {/* Amount Input */}
          <View style={styles.inputRow}>
            <TextInput
              style={styles.tradeInput}
              placeholder="0.00"
              placeholderTextColor="#8B7FAD"
              keyboardType="numeric"
              value={tradeAmount}
              onChangeText={setTradeAmount}
              returnKeyType="done"
            />
            <Text style={styles.inputCurrency}>USDC</Text>
          </View>

          {/* Quick Amounts */}
          <View style={styles.quickAmounts}>
            {[100, 500, 1000, 5000].map((amt) => (
              <Pressable
                key={amt}
                onPress={() => setTradeAmount(amt.toString())}
                style={({ pressed }) => [styles.quickBtn, pressed && { opacity: 0.7 }]}
              >
                <Text style={styles.quickBtnText}>{amt}</Text>
              </Pressable>
            ))}
          </View>

          <View style={styles.orderPreview}>
            <View style={styles.previewRow}>
              <Text style={styles.previewLabel}>Est. keys</Text>
              <Text style={styles.previewValue}>{estimatedKeys > 0 ? estimatedKeys.toFixed(4) : "0.0000"}</Text>
            </View>
            <View style={styles.previewRow}>
              <Text style={styles.previewLabel}>Fee</Text>
              <Text style={styles.previewValue}>{tradingFee > 0 ? `${tradingFee.toFixed(2)} USDC` : "0.00 USDC"}</Text>
            </View>
            <View style={styles.previewRow}>
              <Text style={styles.previewLabel}>Route</Text>
              <Text style={styles.previewValue}>{routeLabel}</Text>
            </View>
          </View>

          {/* Trade Button */}
          <Pressable
            onPress={handleTrade}
            style={({ pressed }) => [
              styles.tradeBtn,
              tradeType === "buy" ? styles.tradeBtnBuy : styles.tradeBtnSell,
              !hasValidAmount && styles.tradeBtnDisabled,
              pressed && { opacity: 0.8, transform: [{ scale: 0.97 }] },
            ]}
          >
            <Text style={styles.tradeBtnText}>
              {tradeType === "buy" ? "Prepare Buy" : "Prepare Sell"}
            </Text>
          </Pressable>
        </View>

        {/* Conviction Vault Section */}
        <View style={styles.vaultSection}>
          <View style={styles.vaultHeader}>
            <Text style={styles.vaultTitle}>Conviction Vault</Text>
            <View style={styles.apyBadge}>
              <Text style={styles.apyText}>~12.4% APY</Text>
            </View>
          </View>
          <Text style={styles.vaultDesc}>
            Stake BID tokens to signal conviction in this agent. Earn yield from protocol fees.
          </Text>

          <View style={styles.vaultStats}>
            <View style={styles.vaultStatItem}>
              <Text style={styles.vaultStatLabel}>TVL</Text>
              <Text style={styles.vaultStatValue}>$24.5K</Text>
            </View>
            <View style={styles.vaultStatItem}>
              <Text style={styles.vaultStatLabel}>Stakers</Text>
              <Text style={styles.vaultStatValue}>142</Text>
            </View>
            <View style={styles.vaultStatItem}>
              <Text style={styles.vaultStatLabel}>Lock Period</Text>
              <Text style={styles.vaultStatValue}>7 days</Text>
            </View>
          </View>

          <View style={styles.inputRow}>
            <TextInput
              style={styles.tradeInput}
              placeholder="0.00"
              placeholderTextColor="#8B7FAD"
              keyboardType="numeric"
              value={stakeAmount}
              onChangeText={setStakeAmount}
              returnKeyType="done"
            />
            <Text style={styles.inputCurrency}>BID</Text>
          </View>

          <Pressable
            onPress={handleStake}
            style={({ pressed }) => [
              styles.stakeBtn,
              pressed && { opacity: 0.8, transform: [{ scale: 0.97 }] },
            ]}
          >
            <Text style={styles.stakeBtnText}>Stake in Vault</Text>
          </Pressable>
        </View>

        {/* Agent Info */}
        <View style={styles.infoSection}>
          <Text style={styles.infoTitle}>Agent Info</Text>
          <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>Status</Text>
            <View style={styles.statusRow}>
              <View style={[styles.statusDot, { backgroundColor: agent.isActive ? "#00D4FF" : "#8B7FAD" }]} />
              <Text style={styles.infoValue}>{agent.isActive ? "Active" : "Inactive"}</Text>
            </View>
          </View>
          <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>Network</Text>
            <Text style={[styles.infoValue, { color: "#0052FF" }]}>Base</Text>
          </View>
          <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>Token</Text>
            <Text style={styles.infoValue}>{agent.symbol}</Text>
          </View>
          <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>DEX</Text>
            <Text style={[styles.infoValue, { color: "#C084FC" }]}>{routeLabel}</Text>
          </View>
          <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>Contract</Text>
            <Text style={[styles.infoValue, { color: "#8B7FAD", fontSize: 11 }]}>
              {agent.tokenAddress ? `${agent.tokenAddress.slice(0, 6)}...${agent.tokenAddress.slice(-4)}` : "0xa183...498B"}
            </Text>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  scrollContent: {
    paddingBottom: 40,
  },
  notFound: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  notFoundText: {
    fontSize: 18,
    color: "#8B7FAD",
    marginBottom: 16,
  },
  loadingText: {
    fontSize: 14,
    color: "#8B7FAD",
    marginTop: 14,
  },
  backBtn: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    backgroundColor: "#7B2FFF22",
    borderRadius: 8,
  },
  backBtnText: {
    color: "#7B2FFF",
    fontWeight: "700",
  },
  topBar: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingRight: 16,
  },
  backRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    paddingHorizontal: 20,
    paddingTop: 12,
    paddingBottom: 8,
  },
  backArrow: {
    fontSize: 20,
    color: "#8B7FAD",
  },
  backLabel: {
    fontSize: 15,
    color: "#8B7FAD",
    fontWeight: "600",
  },
  topActions: {
    flexDirection: "row",
    gap: 8,
  },
  actionBtn: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: "#1E1640",
    alignItems: "center",
    justifyContent: "center",
  },
  actionIcon: {
    fontSize: 18,
    color: "#E8E0FF",
  },
  agentHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "flex-start",
    paddingHorizontal: 20,
    paddingBottom: 16,
  },
  agentHeaderLeft: {},
  agentName: {
    fontSize: 28,
    fontWeight: "800",
    color: "#E8E0FF",
    marginBottom: 2,
  },
  agentSymbol: {
    fontSize: 13,
    fontWeight: "800",
    color: "#7B2FFF",
    marginBottom: 8,
  },
  archetypeBadge: {
    alignSelf: "flex-start",
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 8,
  },
  archetypeText: {
    fontSize: 12,
    fontWeight: "700",
    letterSpacing: 0.5,
  },
  rankCircle: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: "#1E1640",
    alignItems: "center",
    justifyContent: "center",
  },
  rankText: {
    fontSize: 14,
    fontWeight: "800",
    color: "#E8E0FF",
  },
  chartSection: {
    marginHorizontal: 16,
    backgroundColor: "#110E2A",
    borderRadius: 14,
    padding: 16,
    borderWidth: 1,
    borderColor: "#1E1640",
    marginBottom: 16,
  },
  statsGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    paddingHorizontal: 16,
    gap: 8,
    marginBottom: 20,
  },
  statCard: {
    width: "48%",
    backgroundColor: "#110E2A",
    borderRadius: 12,
    padding: 14,
    borderWidth: 1,
    borderColor: "#1E1640",
  },
  statLabel: {
    fontSize: 10,
    fontWeight: "700",
    color: "#8B7FAD",
    letterSpacing: 0.5,
    marginBottom: 6,
  },
  statValue: {
    fontSize: 16,
    fontWeight: "800",
  },
  statValueMuted: {
    fontSize: 16,
    fontWeight: "800",
    color: "#E8E0FF",
  },
  positive: {
    color: "#00D4FF",
  },
  negative: {
    color: "#FF3366",
  },
  tradeSection: {
    marginHorizontal: 16,
    backgroundColor: "#110E2A",
    borderRadius: 16,
    padding: 20,
    borderWidth: 1,
    borderColor: "#1E1640",
    marginBottom: 16,
  },
  tradeSectionTitle: {
    fontSize: 16,
    fontWeight: "700",
    color: "#E8E0FF",
    marginBottom: 6,
  },
  tradeSectionHint: {
    fontSize: 12,
    color: "#8B7FAD",
    lineHeight: 17,
    marginBottom: 16,
  },
  tradeToggle: {
    flexDirection: "row",
    backgroundColor: "#08061A",
    borderRadius: 10,
    padding: 3,
    marginBottom: 16,
  },
  toggleBtn: {
    flex: 1,
    paddingVertical: 10,
    alignItems: "center",
    borderRadius: 8,
  },
  toggleBtnBuy: {
    backgroundColor: "#00D4FF22",
  },
  toggleBtnSell: {
    backgroundColor: "#FF336622",
  },
  toggleText: {
    fontSize: 13,
    fontWeight: "800",
    color: "#8B7FAD",
    letterSpacing: 1,
  },
  toggleTextActive: {
    color: "#E8E0FF",
  },
  inputRow: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#08061A",
    borderRadius: 12,
    borderWidth: 1,
    borderColor: "#1E1640",
    paddingHorizontal: 16,
    marginBottom: 12,
  },
  tradeInput: {
    flex: 1,
    fontSize: 20,
    fontWeight: "700",
    color: "#E8E0FF",
    paddingVertical: 14,
  },
  inputCurrency: {
    fontSize: 14,
    fontWeight: "700",
    color: "#8B7FAD",
  },
  quickAmounts: {
    flexDirection: "row",
    gap: 8,
    marginBottom: 16,
  },
  orderPreview: {
    backgroundColor: "#08061A",
    borderRadius: 12,
    borderWidth: 1,
    borderColor: "#1E1640",
    padding: 12,
    marginBottom: 16,
    gap: 8,
  },
  previewRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    gap: 16,
  },
  previewLabel: {
    fontSize: 12,
    color: "#8B7FAD",
  },
  previewValue: {
    flex: 1,
    textAlign: "right",
    fontSize: 12,
    color: "#E8E0FF",
    fontWeight: "700",
  },
  quickBtn: {
    flex: 1,
    paddingVertical: 8,
    alignItems: "center",
    backgroundColor: "#1E1640",
    borderRadius: 8,
  },
  quickBtnText: {
    fontSize: 12,
    fontWeight: "700",
    color: "#8B7FAD",
  },
  tradeBtn: {
    paddingVertical: 16,
    borderRadius: 12,
    alignItems: "center",
  },
  tradeBtnBuy: {
    backgroundColor: "#00D4FF",
  },
  tradeBtnSell: {
    backgroundColor: "#FF3366",
  },
  tradeBtnDisabled: {
    opacity: 0.55,
  },
  tradeBtnText: {
    fontSize: 16,
    fontWeight: "800",
    color: "#08061A",
  },
  // Conviction Vault
  vaultSection: {
    marginHorizontal: 16,
    backgroundColor: "#110E2A",
    borderRadius: 16,
    padding: 20,
    borderWidth: 1,
    borderColor: "#7B2FFF44",
    marginBottom: 16,
  },
  vaultHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 8,
  },
  vaultTitle: {
    fontSize: 16,
    fontWeight: "700",
    color: "#E8E0FF",
  },
  apyBadge: {
    backgroundColor: "#00D4FF22",
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 8,
  },
  apyText: {
    fontSize: 12,
    fontWeight: "700",
    color: "#00D4FF",
  },
  vaultDesc: {
    fontSize: 13,
    color: "#8B7FAD",
    lineHeight: 18,
    marginBottom: 14,
  },
  vaultStats: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 14,
    paddingVertical: 10,
    borderTopWidth: 1,
    borderBottomWidth: 1,
    borderColor: "#1E1640",
  },
  vaultStatItem: {
    alignItems: "center",
  },
  vaultStatLabel: {
    fontSize: 10,
    fontWeight: "600",
    color: "#8B7FAD",
    marginBottom: 4,
  },
  vaultStatValue: {
    fontSize: 14,
    fontWeight: "700",
    color: "#E8E0FF",
  },
  stakeBtn: {
    paddingVertical: 14,
    borderRadius: 12,
    alignItems: "center",
    backgroundColor: "#7B2FFF",
  },
  stakeBtnText: {
    fontSize: 15,
    fontWeight: "800",
    color: "#FFFFFF",
  },
  // Info Section
  infoSection: {
    marginHorizontal: 16,
    backgroundColor: "#110E2A",
    borderRadius: 14,
    padding: 18,
    borderWidth: 1,
    borderColor: "#1E1640",
  },
  infoTitle: {
    fontSize: 16,
    fontWeight: "700",
    color: "#E8E0FF",
    marginBottom: 14,
  },
  infoRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderBottomColor: "#1E164030",
  },
  infoLabel: {
    fontSize: 14,
    color: "#8B7FAD",
  },
  infoValue: {
    fontSize: 14,
    fontWeight: "700",
    color: "#E8E0FF",
  },
  statusRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
  },
  statusDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },
});
