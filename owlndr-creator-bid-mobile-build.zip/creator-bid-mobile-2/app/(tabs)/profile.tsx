import { Text, View, Pressable, ScrollView, Share } from "react-native";
import { useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { AGENTS, getArchetypeColor, formatUSDC } from "@/lib/mock-data";
import { useWatchlist } from "@/lib/watchlist-store";
import { useNotifications } from "@/lib/notifications-store";
import { StyleSheet, Platform } from "react-native";
import * as Haptics from "expo-haptics";

export default function ProfileScreen() {
  const router = useRouter();
  const { items: watchlistItems } = useWatchlist();
  const { unreadCount } = useNotifications();

  // Map watchlist items to agent data
  const watchlistAgents = watchlistItems
    .map((w) => AGENTS.find((a) => a.id === w.id))
    .filter(Boolean) as typeof AGENTS;

  const handleShareReferral = async () => {
    if (Platform.OS !== "web") {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
    try {
      await Share.share({
        message: "Join me on OWLNDR — the AI agent bidding platform on Base chain!\n\nDiscover, trade, and stake on the best AI agents.\n\nhttps://alpha.creator.bid/?ref=owlndr_user",
        title: "Join OWLNDR",
      });
    } catch (error) {
      // User cancelled
    }
  };

  return (
    <ScreenContainer>
      <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.title}>Profile</Text>
          <Pressable
            onPress={() => router.push("/notifications")}
            style={({ pressed }) => [styles.notifBtn, pressed && { opacity: 0.7 }]}
          >
            <Text style={styles.notifIcon}>🔔</Text>
            {unreadCount > 0 && (
              <View style={styles.badge}>
                <Text style={styles.badgeText}>{unreadCount > 9 ? "9+" : unreadCount}</Text>
              </View>
            )}
          </Pressable>
        </View>

        {/* Avatar & Address */}
        <View style={styles.profileCard}>
          <View style={styles.avatar}>
            <Text style={styles.avatarText}>🦉</Text>
          </View>
          <Text style={styles.displayName}>OWLNDR User</Text>
          <Text style={styles.walletAddress}>0x7a3B...4f2E</Text>
          <View style={styles.networkBadge}>
            <View style={styles.baseDot} />
            <Text style={styles.networkText}>Base Network</Text>
          </View>
        </View>

        {/* Portfolio Summary */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Portfolio</Text>
          <View style={styles.portfolioCard}>
            <View style={styles.portfolioRow}>
              <View>
                <Text style={styles.portfolioLabel}>Total Value</Text>
                <Text style={styles.portfolioValue}>$18,650.32</Text>
              </View>
              <View style={styles.portfolioRight}>
                <Text style={styles.portfolioLabel}>P&L (24h)</Text>
                <Text style={styles.portfolioPnl}>+$1,240.50</Text>
              </View>
            </View>
            <View style={styles.portfolioBar}>
              <View style={[styles.barSegment, { flex: 5, backgroundColor: "#0052FF" }]} />
              <View style={[styles.barSegment, { flex: 3, backgroundColor: "#7B2FFF" }]} />
              <View style={[styles.barSegment, { flex: 2, backgroundColor: "#00D4FF" }]} />
            </View>
            <View style={styles.legendRow}>
              <View style={styles.legendItem}>
                <View style={[styles.legendDot, { backgroundColor: "#0052FF" }]} />
                <Text style={styles.legendText}>USDC</Text>
              </View>
              <View style={styles.legendItem}>
                <View style={[styles.legendDot, { backgroundColor: "#7B2FFF" }]} />
                <Text style={styles.legendText}>BID</Text>
              </View>
              <View style={styles.legendItem}>
                <View style={[styles.legendDot, { backgroundColor: "#00D4FF" }]} />
                <Text style={styles.legendText}>ETH</Text>
              </View>
            </View>
          </View>
        </View>

        {/* Watchlist */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Watchlist</Text>
            <Text style={styles.sectionCount}>{watchlistAgents.length} agents</Text>
          </View>
          {watchlistAgents.length > 0 ? (
            watchlistAgents.map((agent) => (
              <Pressable
                key={agent.id}
                onPress={() => router.push(`/agent/${agent.id}`)}
                style={({ pressed }) => [styles.watchlistItem, pressed && { opacity: 0.7 }]}
              >
                <View>
                  <Text style={styles.watchName}>{agent.name}</Text>
                  <Text style={[styles.watchArchetype, { color: getArchetypeColor(agent.archetype) }]}>{agent.archetype}</Text>
                </View>
                <View style={styles.watchStats}>
                  <Text style={[styles.watchReturn, agent.returnPct >= 0 ? styles.positive : styles.negative]}>
                    {agent.returnPct > 0 ? "+" : ""}{agent.returnPct}%
                  </Text>
                  <Text style={styles.watchWinnings}>{formatUSDC(agent.winnings)}</Text>
                </View>
              </Pressable>
            ))
          ) : (
            <View style={styles.emptyWatchlist}>
              <Text style={styles.emptyText}>No agents in watchlist yet</Text>
              <Text style={styles.emptySubtext}>Tap the star icon on any agent to add it</Text>
            </View>
          )}
        </View>

        {/* Referral Section */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Invite Friends</Text>
          <View style={styles.referralCard}>
            <Text style={styles.referralTitle}>Share OWLNDR</Text>
            <Text style={styles.referralDesc}>
              Invite friends to earn 5% of their trading fees for 90 days.
            </Text>
            <Pressable
              onPress={handleShareReferral}
              style={({ pressed }) => [styles.referralBtn, pressed && { opacity: 0.8, transform: [{ scale: 0.97 }] }]}
            >
              <Text style={styles.referralBtnText}>Share Invite Link</Text>
            </Pressable>
          </View>
        </View>

        {/* Settings */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Settings</Text>
          <View style={styles.settingsCard}>
            <Pressable
              onPress={() => router.push("/notifications")}
              style={({ pressed }) => [styles.settingsRow, pressed && { opacity: 0.7 }]}
            >
              <Text style={styles.settingsLabel}>Notifications</Text>
              <Text style={styles.settingsValue}>{unreadCount > 0 ? `${unreadCount} new` : "On"}</Text>
            </Pressable>
            <Pressable style={({ pressed }) => [styles.settingsRow, pressed && { opacity: 0.7 }]}>
              <Text style={styles.settingsLabel}>Default Slippage</Text>
              <Text style={styles.settingsValue}>0.5%</Text>
            </Pressable>
            <Pressable style={({ pressed }) => [styles.settingsRow, pressed && { opacity: 0.7 }]}>
              <Text style={styles.settingsLabel}>Network</Text>
              <Text style={[styles.settingsValue, { color: "#0052FF" }]}>Base</Text>
            </Pressable>
            <Pressable style={({ pressed }) => [styles.settingsRow, styles.settingsRowLast, pressed && { opacity: 0.7 }]}>
              <Text style={styles.settingsLabel}>About OWLNDR</Text>
              <Text style={styles.settingsValue}>v2.0.0</Text>
            </Pressable>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  scrollContent: {
    paddingBottom: 30,
  },
  header: {
    paddingHorizontal: 20,
    paddingTop: 12,
    paddingBottom: 8,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  title: {
    fontSize: 28,
    fontWeight: "800",
    color: "#E8E0FF",
  },
  notifBtn: {
    position: "relative",
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: "#1E1640",
    alignItems: "center",
    justifyContent: "center",
  },
  notifIcon: {
    fontSize: 18,
  },
  badge: {
    position: "absolute",
    top: -2,
    right: -2,
    backgroundColor: "#FF3366",
    borderRadius: 10,
    minWidth: 18,
    height: 18,
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: 4,
  },
  badgeText: {
    fontSize: 10,
    fontWeight: "800",
    color: "#FFFFFF",
  },
  profileCard: {
    alignItems: "center",
    paddingVertical: 24,
    marginHorizontal: 16,
    backgroundColor: "#110E2A",
    borderRadius: 16,
    borderWidth: 1,
    borderColor: "#1E1640",
    marginBottom: 24,
  },
  avatar: {
    width: 64,
    height: 64,
    borderRadius: 32,
    backgroundColor: "#1E1640",
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 12,
  },
  avatarText: {
    fontSize: 32,
  },
  displayName: {
    fontSize: 18,
    fontWeight: "800",
    color: "#E8E0FF",
    marginBottom: 4,
  },
  walletAddress: {
    fontSize: 14,
    color: "#8B7FAD",
    fontFamily: Platform.OS === "ios" ? "Menlo" : "monospace",
    marginBottom: 8,
  },
  networkBadge: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    backgroundColor: "#0052FF22",
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 12,
  },
  baseDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: "#0052FF",
  },
  networkText: {
    fontSize: 12,
    fontWeight: "600",
    color: "#0052FF",
  },
  section: {
    paddingHorizontal: 16,
    marginBottom: 24,
  },
  sectionHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 12,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: "700",
    color: "#E8E0FF",
    marginBottom: 12,
  },
  sectionCount: {
    fontSize: 12,
    color: "#8B7FAD",
    fontWeight: "600",
    marginBottom: 12,
  },
  portfolioCard: {
    backgroundColor: "#110E2A",
    borderRadius: 14,
    padding: 18,
    borderWidth: 1,
    borderColor: "#1E1640",
  },
  portfolioRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 16,
  },
  portfolioLabel: {
    fontSize: 12,
    color: "#8B7FAD",
    marginBottom: 4,
  },
  portfolioValue: {
    fontSize: 24,
    fontWeight: "800",
    color: "#E8E0FF",
  },
  portfolioRight: {
    alignItems: "flex-end",
  },
  portfolioPnl: {
    fontSize: 18,
    fontWeight: "700",
    color: "#00D4FF",
  },
  portfolioBar: {
    flexDirection: "row",
    height: 6,
    borderRadius: 3,
    overflow: "hidden",
    marginBottom: 12,
  },
  barSegment: {
    height: 6,
  },
  legendRow: {
    flexDirection: "row",
    gap: 16,
  },
  legendItem: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
  },
  legendDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  legendText: {
    fontSize: 12,
    color: "#8B7FAD",
  },
  watchlistItem: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingVertical: 14,
    borderBottomWidth: 1,
    borderBottomColor: "#1E164030",
  },
  watchName: {
    fontSize: 15,
    fontWeight: "700",
    color: "#E8E0FF",
    marginBottom: 2,
  },
  watchArchetype: {
    fontSize: 11,
    fontWeight: "600",
  },
  watchStats: {
    alignItems: "flex-end",
  },
  watchReturn: {
    fontSize: 14,
    fontWeight: "700",
    marginBottom: 2,
  },
  watchWinnings: {
    fontSize: 11,
    color: "#8B7FAD",
  },
  positive: {
    color: "#00D4FF",
  },
  negative: {
    color: "#FF3366",
  },
  emptyWatchlist: {
    alignItems: "center",
    paddingVertical: 24,
    backgroundColor: "#110E2A",
    borderRadius: 12,
    borderWidth: 1,
    borderColor: "#1E1640",
  },
  emptyText: {
    fontSize: 14,
    fontWeight: "600",
    color: "#8B7FAD",
    marginBottom: 4,
  },
  emptySubtext: {
    fontSize: 12,
    color: "#5A4F7A",
  },
  // Referral
  referralCard: {
    backgroundColor: "#110E2A",
    borderRadius: 14,
    padding: 18,
    borderWidth: 1,
    borderColor: "#7B2FFF44",
  },
  referralTitle: {
    fontSize: 16,
    fontWeight: "700",
    color: "#E8E0FF",
    marginBottom: 6,
  },
  referralDesc: {
    fontSize: 13,
    color: "#8B7FAD",
    lineHeight: 18,
    marginBottom: 14,
  },
  referralBtn: {
    backgroundColor: "#7B2FFF",
    paddingVertical: 12,
    borderRadius: 10,
    alignItems: "center",
  },
  referralBtnText: {
    fontSize: 14,
    fontWeight: "700",
    color: "#FFFFFF",
  },
  // Settings
  settingsCard: {
    backgroundColor: "#110E2A",
    borderRadius: 14,
    borderWidth: 1,
    borderColor: "#1E1640",
    overflow: "hidden",
  },
  settingsRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: "#1E164030",
  },
  settingsRowLast: {
    borderBottomWidth: 0,
  },
  settingsLabel: {
    fontSize: 15,
    color: "#E8E0FF",
  },
  settingsValue: {
    fontSize: 14,
    color: "#8B7FAD",
    fontWeight: "600",
  },
});
