import { FlatList, Text, View, Pressable, ScrollView, RefreshControl } from "react-native";
import { useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { getArchetypeColor, formatUSDC } from "@/lib/mock-data";
import { useAgentTokens, useProtocolStats } from "@/hooks/use-live-data";
import { formatVolume, formatPrice, formatPriceChange } from "@/lib/api";
import { type DisplayAgent, getDisplayAgents } from "@/lib/agent-data";
import { StyleSheet } from "react-native";
import { useState, useCallback, useMemo } from "react";

function SkeletonBlock({ width, height }: { width: number | string; height: number }) {
  return (
    <View
      style={[
        styles.skeleton,
        { width: width as any, height },
      ]}
    />
  );
}

function ProtocolStatsBanner() {
  const { data: stats, isLoading, error } = useProtocolStats();

  if (isLoading) {
    return (
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.statsBanner}>
        {[1, 2, 3, 4, 5, 6].map((i) => (
          <View key={i} style={styles.statItem}>
            <SkeletonBlock width={40} height={10} />
            <SkeletonBlock width={50} height={16} />
          </View>
        ))}
      </ScrollView>
    );
  }

  if (!stats || error) {
    return (
      <View style={[styles.statsBanner, { paddingVertical: 16, alignItems: "center" as any }]}>
        <Text style={styles.errorText}>Unable to load live data</Text>
      </View>
    );
  }

  return (
    <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.statsBanner}>
      <View style={styles.statItem}>
        <Text style={styles.statLabel}>STATUS</Text>
        <View style={styles.liveRow}>
          <View style={styles.liveDot} />
          <Text style={styles.statValueLive}>{stats.status}</Text>
        </View>
      </View>
      <View style={styles.statItem}>
        <Text style={styles.statLabel}>PRICE</Text>
        <Text style={styles.statValue}>{formatPrice(stats.priceUsd)}</Text>
      </View>
      <View style={styles.statItem}>
        <Text style={styles.statLabel}>24H</Text>
        <Text style={[styles.statValue, stats.priceChange24h >= 0 ? styles.positive : styles.negative]}>
          {formatPriceChange(stats.priceChange24h)}
        </Text>
      </View>
      <View style={styles.statItem}>
        <Text style={styles.statLabel}>VOLUME</Text>
        <Text style={styles.statValue}>{formatVolume(stats.volume24h)}</Text>
      </View>
      <View style={styles.statItem}>
        <Text style={styles.statLabel}>BUYS</Text>
        <Text style={styles.statValue}>{stats.buys24h}</Text>
      </View>
      <View style={styles.statItem}>
        <Text style={styles.statLabel}>SELLS</Text>
        <Text style={styles.statValue}>{stats.sells24h}</Text>
      </View>
      <View style={styles.statItem}>
        <Text style={styles.statLabel}>LIQUIDITY</Text>
        <Text style={styles.statValue}>{formatVolume(stats.liquidity)}</Text>
      </View>
      <View style={styles.statItem}>
        <Text style={styles.statLabel}>MCAP</Text>
        <Text style={styles.statValueAccent}>{formatVolume(stats.marketCap)}</Text>
      </View>
      <View style={styles.statItem}>
        <Text style={styles.statLabel}>TOKEN</Text>
        <Text style={styles.statValueAccent}>{stats.token}</Text>
      </View>
      <View style={styles.statItem}>
        <Text style={styles.statLabel}>DEX</Text>
        <Text style={styles.statValue}>{stats.dex.toUpperCase()}</Text>
      </View>
    </ScrollView>
  );
}

function PodiumCard({ agent, medal }: { agent: DisplayAgent; medal: string }) {
  const router = useRouter();
  const isFirst = agent.rank === 1;
  return (
    <Pressable
      onPress={() => router.push(`/agent/${agent.id}`)}
      style={({ pressed }) => [
        styles.podiumCard,
        isFirst && styles.podiumCardFirst,
        pressed && { opacity: 0.7 },
      ]}
    >
      <Text style={styles.medal}>{medal}</Text>
      <Text style={styles.podiumRank}>{agent.rank === 1 ? "1ST" : agent.rank === 2 ? "2ND" : "3RD"} PLACE</Text>
      <Text style={styles.podiumName}>{agent.name}</Text>
      <View style={[styles.archetypeBadge, { backgroundColor: getArchetypeColor(agent.archetype) + "22" }]}>
        <Text style={[styles.archetypeText, { color: getArchetypeColor(agent.archetype) }]}>{agent.archetype}</Text>
      </View>
      <Text style={[styles.podiumWinnings, agent.winnings >= 0 ? styles.positive : styles.negative]}>
        {formatUSDC(agent.winnings)}
      </Text>
      <Text style={styles.podiumReturn}>{agent.returnPct > 0 ? "+" : ""}{agent.returnPct}% · {agent.fills} fills</Text>
      {agent.source === "live" && <Text style={styles.liveSource}>{agent.symbol} · {agent.dexId?.toUpperCase()}</Text>}
    </Pressable>
  );
}

function LeaderboardRow({ agent }: { agent: DisplayAgent }) {
  const router = useRouter();
  return (
    <Pressable
      onPress={() => router.push(`/agent/${agent.id}`)}
      style={({ pressed }) => [styles.leaderboardRow, pressed && { opacity: 0.7 }]}
    >
      <Text style={styles.rowRank}>{agent.rank}</Text>
      <View style={styles.rowNameCol}>
        <Text style={styles.rowName}>{agent.name}</Text>
        <Text style={[styles.rowArchetype, { color: getArchetypeColor(agent.archetype) }]}>{agent.archetype}</Text>
      </View>
      <View style={styles.rowStatsCol}>
        <Text style={[styles.rowWinnings, agent.winnings >= 0 ? styles.positive : styles.negative]}>
          {formatUSDC(agent.winnings)}
        </Text>
        <Text style={styles.rowReturn}>{agent.returnPct > 0 ? "+" : ""}{agent.returnPct}%</Text>
      </View>
      <Text style={styles.rowFills}>{agent.fills}</Text>
    </Pressable>
  );
}

export default function HomeScreen() {
  const { data: liveAgents, refetch: refetchAgents } = useAgentTokens();
  const { refetch: refetchStats } = useProtocolStats();
  const agents = useMemo(() => getDisplayAgents(liveAgents), [liveAgents]);
  const topThree = agents.filter((a) => a.rank <= 3).sort((a, b) => a.rank - b.rank);
  const rest = agents.filter((a) => a.rank > 3).sort((a, b) => a.rank - b.rank);
  const medals = ["🥇", "🥈", "🥉"];
  const [refreshing, setRefreshing] = useState(false);

  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    await Promise.all([refetchStats(), refetchAgents()]);
    setRefreshing(false);
  }, [refetchAgents, refetchStats]);

  return (
    <ScreenContainer>
      <FlatList
        data={rest}
        keyExtractor={(item) => item.id}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefresh}
            tintColor="#7B2FFF"
            colors={["#7B2FFF"]}
          />
        }
        ListHeaderComponent={
          <View>
            {/* Header */}
            <View style={styles.header}>
              <Text style={styles.headerTitle}>OWLNDR</Text>
              <Text style={styles.headerSubtitle}>CREATORBID AGENTS</Text>
              <View style={styles.liveIndicator}>
                <View style={styles.liveDotSmall} />
                <Text style={styles.liveText}>{liveAgents?.length ? "LIVE" : "DEMO"}</Text>
              </View>
            </View>

            {/* Protocol Stats - Live Data */}
            <ProtocolStatsBanner />

            {/* Top 3 Podium */}
            <View style={styles.podiumSection}>
              {topThree.map((agent, idx) => (
                <PodiumCard key={agent.id} agent={agent} medal={medals[idx]} />
              ))}
            </View>

            {/* Leaderboard Header */}
            <View style={styles.leaderboardHeader}>
              <Text style={styles.lbHeaderRank}>#</Text>
              <Text style={styles.lbHeaderName}>NAME</Text>
              <Text style={styles.lbHeaderWinnings}>WINNINGS</Text>
              <Text style={styles.lbHeaderFills}>FILLS</Text>
            </View>
          </View>
        }
        renderItem={({ item }) => <LeaderboardRow agent={item} />}
        contentContainerStyle={styles.listContent}
        showsVerticalScrollIndicator={false}
      />
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  listContent: {
    paddingBottom: 20,
  },
  header: {
    paddingHorizontal: 20,
    paddingTop: 12,
    paddingBottom: 8,
    flexDirection: "row",
    alignItems: "baseline",
    gap: 10,
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: "800",
    color: "#E8E0FF",
    letterSpacing: 2,
  },
  headerSubtitle: {
    fontSize: 12,
    fontWeight: "600",
    color: "#7B2FFF",
    letterSpacing: 1,
  },
  liveIndicator: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
    marginLeft: "auto",
    backgroundColor: "#00D4FF11",
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 10,
  },
  liveDotSmall: {
    width: 5,
    height: 5,
    borderRadius: 3,
    backgroundColor: "#00D4FF",
  },
  liveText: {
    fontSize: 10,
    fontWeight: "700",
    color: "#00D4FF",
    letterSpacing: 0.5,
  },
  statsBanner: {
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: "#1E1640",
  },
  statItem: {
    marginRight: 20,
    alignItems: "center",
    gap: 4,
  },
  statLabel: {
    fontSize: 10,
    fontWeight: "600",
    color: "#8B7FAD",
    letterSpacing: 0.5,
  },
  statValue: {
    fontSize: 14,
    fontWeight: "700",
    color: "#E8E0FF",
  },
  statValueLive: {
    fontSize: 14,
    fontWeight: "700",
    color: "#00D4FF",
  },
  statValueAccent: {
    fontSize: 14,
    fontWeight: "700",
    color: "#C084FC",
  },
  liveRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
  },
  liveDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: "#00D4FF",
  },
  errorText: {
    fontSize: 12,
    color: "#FF3366",
    fontWeight: "600",
  },
  skeleton: {
    backgroundColor: "#1E1640",
    borderRadius: 4,
    marginVertical: 2,
  },
  podiumSection: {
    paddingHorizontal: 16,
    paddingVertical: 16,
    gap: 10,
  },
  podiumCard: {
    backgroundColor: "#110E2A",
    borderRadius: 16,
    padding: 16,
    borderWidth: 1,
    borderColor: "#1E1640",
  },
  podiumCardFirst: {
    borderColor: "#7B2FFF",
    backgroundColor: "#13102E",
  },
  medal: {
    fontSize: 20,
    marginBottom: 4,
  },
  podiumRank: {
    fontSize: 11,
    fontWeight: "700",
    color: "#8B7FAD",
    letterSpacing: 1,
    marginBottom: 4,
  },
  podiumName: {
    fontSize: 20,
    fontWeight: "800",
    color: "#E8E0FF",
    marginBottom: 6,
  },
  archetypeBadge: {
    alignSelf: "flex-start",
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 6,
    marginBottom: 8,
  },
  archetypeText: {
    fontSize: 11,
    fontWeight: "700",
    letterSpacing: 0.5,
  },
  podiumWinnings: {
    fontSize: 18,
    fontWeight: "700",
    marginBottom: 4,
  },
  podiumReturn: {
    fontSize: 13,
    color: "#8B7FAD",
  },
  liveSource: {
    fontSize: 11,
    color: "#7B2FFF",
    marginTop: 6,
    fontWeight: "700",
  },
  positive: {
    color: "#00D4FF",
  },
  negative: {
    color: "#FF3366",
  },
  leaderboardHeader: {
    flexDirection: "row",
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderBottomColor: "#1E1640",
    alignItems: "center",
  },
  lbHeaderRank: {
    width: 30,
    fontSize: 11,
    fontWeight: "600",
    color: "#8B7FAD",
  },
  lbHeaderName: {
    flex: 1,
    fontSize: 11,
    fontWeight: "600",
    color: "#8B7FAD",
  },
  lbHeaderWinnings: {
    width: 100,
    fontSize: 11,
    fontWeight: "600",
    color: "#8B7FAD",
    textAlign: "right",
  },
  lbHeaderFills: {
    width: 40,
    fontSize: 11,
    fontWeight: "600",
    color: "#8B7FAD",
    textAlign: "right",
  },
  leaderboardRow: {
    flexDirection: "row",
    paddingHorizontal: 20,
    paddingVertical: 14,
    borderBottomWidth: 1,
    borderBottomColor: "#1E164020",
    alignItems: "center",
  },
  rowRank: {
    width: 30,
    fontSize: 14,
    fontWeight: "700",
    color: "#8B7FAD",
  },
  rowNameCol: {
    flex: 1,
  },
  rowName: {
    fontSize: 15,
    fontWeight: "700",
    color: "#E8E0FF",
    marginBottom: 2,
  },
  rowArchetype: {
    fontSize: 11,
    fontWeight: "600",
  },
  rowStatsCol: {
    width: 100,
    alignItems: "flex-end",
  },
  rowWinnings: {
    fontSize: 13,
    fontWeight: "700",
    marginBottom: 2,
  },
  rowReturn: {
    fontSize: 11,
    color: "#8B7FAD",
  },
  rowFills: {
    width: 40,
    fontSize: 14,
    fontWeight: "600",
    color: "#8B7FAD",
    textAlign: "right",
  },
});
