import { FlatList, Text, View, Pressable, TextInput, ScrollView, ActivityIndicator, RefreshControl } from "react-native";
import { useState, useMemo } from "react";
import { useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { ARCHETYPES, getArchetypeColor, formatUSDC, AgentArchetype } from "@/lib/mock-data";
import { useAgentTokens, useSearchPairs } from "@/hooks/use-live-data";
import { formatPrice, formatPriceChange } from "@/lib/api";
import { type DisplayAgent, getDisplayAgents } from "@/lib/agent-data";
import { StyleSheet } from "react-native";

function TrendingBanner({ agents }: { agents: DisplayAgent[] }) {
  // Show top 3 movers
  const trending = agents.slice().sort((a, b) => Math.abs(b.returnPct) - Math.abs(a.returnPct)).slice(0, 3);
  const router = useRouter();

  return (
    <View style={styles.trendingSection}>
      <Text style={styles.trendingTitle}>Trending Now</Text>
      <ScrollView horizontal showsHorizontalScrollIndicator={false}>
        {trending.map((agent) => (
          <Pressable
            key={agent.id}
            onPress={() => router.push(`/agent/${agent.id}`)}
            style={({ pressed }) => [styles.trendingCard, pressed && { opacity: 0.7 }]}
          >
            <Text style={styles.trendingName}>{agent.name}</Text>
            <Text style={[styles.trendingReturn, agent.returnPct >= 0 ? styles.positive : styles.negative]}>
              {agent.returnPct > 0 ? "+" : ""}{agent.returnPct}%
            </Text>
            <Text style={styles.trendingFills}>{agent.fills} fills</Text>
          </Pressable>
        ))}
      </ScrollView>
    </View>
  );
}

export default function ExploreScreen() {
  const router = useRouter();
  const [search, setSearch] = useState("");
  const [selectedArchetype, setSelectedArchetype] = useState<AgentArchetype | "ALL">("ALL");
  const { data: searchResults, isLoading: searchLoading } = useSearchPairs(search);
  const { data: liveAgents, refetch, isRefetching } = useAgentTokens();
  const agents = useMemo(() => getDisplayAgents(liveAgents), [liveAgents]);

  const filteredAgents = useMemo(() => {
    let result = agents;
    if (search.trim()) {
      result = result.filter((a) =>
        a.name.toLowerCase().includes(search.toLowerCase()) ||
        a.symbol.toLowerCase().includes(search.toLowerCase())
      );
    }
    if (selectedArchetype !== "ALL") {
      result = result.filter((a) => a.archetype === selectedArchetype);
    }
    return result.sort((a, b) => a.rank - b.rank);
  }, [agents, search, selectedArchetype]);

  return (
    <ScreenContainer>
      <View style={styles.header}>
        <Text style={styles.title}>Explore</Text>
        <Text style={styles.subtitle}>{liveAgents?.length ? "Live Base markets and CreatorBid watchlist" : "Discover AI agents on Base"}</Text>
      </View>

      {/* Search */}
      <View style={styles.searchContainer}>
        <View style={styles.searchRow}>
          <Text style={styles.searchIcon}>⌕</Text>
          <TextInput
            style={styles.searchInput}
            placeholder="Search agents or tokens..."
            placeholderTextColor="#8B7FAD"
            value={search}
            onChangeText={setSearch}
            returnKeyType="done"
          />
          {searchLoading && <ActivityIndicator size="small" color="#7B2FFF" />}
        </View>
      </View>

      {/* Filter Chips */}
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.filterRow}>
        <Pressable
          onPress={() => setSelectedArchetype("ALL")}
          style={({ pressed }) => [
            styles.chip,
            selectedArchetype === "ALL" && styles.chipActive,
            pressed && { opacity: 0.7 },
          ]}
        >
          <Text style={[styles.chipText, selectedArchetype === "ALL" && styles.chipTextActive]}>ALL</Text>
        </Pressable>
        {ARCHETYPES.map((arch) => (
          <Pressable
            key={arch}
            onPress={() => setSelectedArchetype(arch)}
            style={({ pressed }) => [
              styles.chip,
              selectedArchetype === arch && { backgroundColor: getArchetypeColor(arch) + "33", borderColor: getArchetypeColor(arch) },
              pressed && { opacity: 0.7 },
            ]}
          >
            <Text style={[styles.chipText, selectedArchetype === arch && { color: getArchetypeColor(arch) }]}>{arch}</Text>
          </Pressable>
        ))}
      </ScrollView>

      {/* Agent List */}
      <FlatList
        data={filteredAgents}
        keyExtractor={(item) => item.id}
        refreshControl={<RefreshControl refreshing={isRefetching} onRefresh={refetch} tintColor="#7B2FFF" colors={["#7B2FFF"]} />}
        ListHeaderComponent={!search.trim() && selectedArchetype === "ALL" ? <TrendingBanner agents={agents} /> : null}
        renderItem={({ item }) => (
          <Pressable
            onPress={() => router.push(`/agent/${item.id}`)}
            style={({ pressed }) => [styles.agentCard, pressed && { opacity: 0.7, transform: [{ scale: 0.98 }] }]}
          >
            <View style={styles.cardTop}>
              <View style={styles.cardTopLeft}>
                <View style={styles.agentAvatar}>
                  <Text style={styles.agentAvatarText}>{item.name.charAt(0)}</Text>
                </View>
                <View>
                <Text style={styles.agentName}>{item.name}</Text>
                  {item.source === "live" && <Text style={styles.agentSymbol}>{item.symbol}</Text>}
                  <View style={[styles.archetypeBadge, { backgroundColor: getArchetypeColor(item.archetype) + "22" }]}>
                    <Text style={[styles.archetypeLabel, { color: getArchetypeColor(item.archetype) }]}>{item.archetype}</Text>
                  </View>
                </View>
              </View>
              <View style={styles.cardTopRight}>
                <Text style={styles.rankBadge}>#{item.rank}</Text>
                <View style={[styles.statusIndicator, { backgroundColor: item.isActive ? "#00D4FF" : "#8B7FAD" }]} />
              </View>
            </View>
            <View style={styles.cardBottom}>
              <View>
                <Text style={styles.cardStatLabel}>WINNINGS</Text>
                <Text style={[styles.cardStatValue, item.winnings >= 0 ? styles.positive : styles.negative]}>
                  {formatUSDC(item.winnings)}
                </Text>
              </View>
              <View style={styles.cardStatRight}>
                <Text style={styles.cardStatLabel}>RETURN</Text>
                <Text style={[styles.cardStatValue, item.returnPct >= 0 ? styles.positive : styles.negative]}>
                  {item.returnPct > 0 ? "+" : ""}{item.returnPct}%
                </Text>
              </View>
              <View style={styles.cardStatRight}>
                <Text style={styles.cardStatLabel}>FILLS</Text>
                <Text style={styles.cardStatValueMuted}>{item.fills}</Text>
              </View>
            </View>
          </Pressable>
        )}
        contentContainerStyle={styles.listContent}
        showsVerticalScrollIndicator={false}
        ListEmptyComponent={
          <View style={styles.emptyState}>
            <Text style={styles.emptyIcon}>🔍</Text>
            <Text style={styles.emptyText}>No agents found</Text>
            <Text style={styles.emptySubtext}>Try a different search or filter</Text>
          </View>
        }
      />

      {/* Live Search Results from DexScreener */}
      {search.trim().length > 1 && searchResults && searchResults.length > 0 && (
        <View style={styles.liveResultsOverlay}>
          <Text style={styles.liveResultsTitle}>Live on Base</Text>
          {searchResults.slice(0, 5).map((pair) => (
            <Pressable
              key={pair.pairAddress}
              onPress={() => router.push(`/agent/${pair.pairAddress}`)}
              style={({ pressed }) => [styles.liveResultItem, pressed && { opacity: 0.7 }]}
            >
              <View>
                <Text style={styles.liveResultName}>{pair.baseToken.name}</Text>
                <Text style={styles.liveResultSymbol}>{pair.baseToken.symbol}</Text>
              </View>
              <View style={styles.liveResultRight}>
                <Text style={styles.liveResultPrice}>{formatPrice(parseFloat(pair.priceUsd || "0"))}</Text>
                <Text style={[styles.liveResultChange, (pair.priceChange?.h24 ?? 0) >= 0 ? styles.positive : styles.negative]}>
                  {formatPriceChange(pair.priceChange?.h24 ?? 0)}
                </Text>
              </View>
            </Pressable>
          ))}
        </View>
      )}
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  header: {
    paddingHorizontal: 20,
    paddingTop: 12,
    paddingBottom: 4,
  },
  title: {
    fontSize: 24,
    fontWeight: "800",
    color: "#E8E0FF",
  },
  subtitle: {
    fontSize: 13,
    color: "#8B7FAD",
    marginTop: 2,
  },
  searchContainer: {
    paddingHorizontal: 16,
    paddingVertical: 12,
  },
  searchRow: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#110E2A",
    borderRadius: 12,
    paddingHorizontal: 14,
    borderWidth: 1,
    borderColor: "#1E1640",
  },
  searchIcon: {
    fontSize: 18,
    color: "#8B7FAD",
    marginRight: 8,
  },
  searchInput: {
    flex: 1,
    paddingVertical: 12,
    fontSize: 15,
    color: "#E8E0FF",
  },
  filterRow: {
    paddingHorizontal: 16,
    paddingBottom: 12,
    maxHeight: 44,
  },
  chip: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: "#1E1640",
    backgroundColor: "#110E2A",
    marginRight: 8,
  },
  chipActive: {
    backgroundColor: "#7B2FFF22",
    borderColor: "#7B2FFF",
  },
  chipText: {
    fontSize: 11,
    fontWeight: "700",
    color: "#8B7FAD",
    letterSpacing: 0.5,
  },
  chipTextActive: {
    color: "#7B2FFF",
  },
  // Trending
  trendingSection: {
    marginBottom: 16,
  },
  trendingTitle: {
    fontSize: 14,
    fontWeight: "700",
    color: "#E8E0FF",
    marginBottom: 10,
  },
  trendingCard: {
    backgroundColor: "#13102E",
    borderRadius: 12,
    padding: 14,
    marginRight: 10,
    borderWidth: 1,
    borderColor: "#7B2FFF33",
    width: 130,
  },
  trendingName: {
    fontSize: 13,
    fontWeight: "700",
    color: "#E8E0FF",
    marginBottom: 4,
  },
  trendingReturn: {
    fontSize: 16,
    fontWeight: "800",
    marginBottom: 2,
  },
  trendingFills: {
    fontSize: 11,
    color: "#8B7FAD",
  },
  // Agent Cards
  listContent: {
    paddingHorizontal: 16,
    paddingBottom: 20,
  },
  agentCard: {
    backgroundColor: "#110E2A",
    borderRadius: 14,
    padding: 16,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: "#1E1640",
  },
  cardTop: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "flex-start",
    marginBottom: 12,
  },
  cardTopLeft: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
  },
  agentAvatar: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: "#1E1640",
    alignItems: "center",
    justifyContent: "center",
  },
  agentAvatarText: {
    fontSize: 16,
    fontWeight: "800",
    color: "#7B2FFF",
  },
  cardTopRight: {
    alignItems: "flex-end",
    gap: 4,
  },
  statusIndicator: {
    width: 6,
    height: 6,
    borderRadius: 3,
  },
  agentName: {
    fontSize: 16,
    fontWeight: "800",
    color: "#E8E0FF",
  },
  agentSymbol: {
    fontSize: 11,
    color: "#7B2FFF",
    fontWeight: "700",
    marginTop: 1,
    marginBottom: 4,
  },
  archetypeBadge: {
    alignSelf: "flex-start",
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 6,
  },
  archetypeLabel: {
    fontSize: 10,
    fontWeight: "700",
    letterSpacing: 0.5,
  },
  rankBadge: {
    fontSize: 14,
    fontWeight: "700",
    color: "#8B7FAD",
  },
  cardBottom: {
    flexDirection: "row",
    alignItems: "flex-end",
  },
  cardStatLabel: {
    fontSize: 10,
    fontWeight: "600",
    color: "#8B7FAD",
    marginBottom: 2,
    letterSpacing: 0.5,
  },
  cardStatValue: {
    fontSize: 14,
    fontWeight: "700",
  },
  cardStatValueMuted: {
    fontSize: 14,
    fontWeight: "700",
    color: "#E8E0FF",
  },
  cardStatRight: {
    marginLeft: 20,
  },
  positive: {
    color: "#00D4FF",
  },
  negative: {
    color: "#FF3366",
  },
  emptyState: {
    alignItems: "center",
    paddingTop: 60,
  },
  emptyIcon: {
    fontSize: 36,
    marginBottom: 12,
  },
  emptyText: {
    fontSize: 16,
    fontWeight: "600",
    color: "#8B7FAD",
    marginBottom: 4,
  },
  emptySubtext: {
    fontSize: 13,
    color: "#5A4F7A",
  },
  // Live Results
  liveResultsOverlay: {
    position: "absolute",
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: "#110E2AEE",
    borderTopWidth: 1,
    borderTopColor: "#7B2FFF44",
    padding: 16,
    borderTopLeftRadius: 16,
    borderTopRightRadius: 16,
  },
  liveResultsTitle: {
    fontSize: 12,
    fontWeight: "700",
    color: "#7B2FFF",
    letterSpacing: 0.5,
    marginBottom: 10,
  },
  liveResultItem: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingVertical: 8,
    borderBottomWidth: 1,
    borderBottomColor: "#1E164030",
  },
  liveResultName: {
    fontSize: 14,
    fontWeight: "700",
    color: "#E8E0FF",
  },
  liveResultSymbol: {
    fontSize: 11,
    color: "#8B7FAD",
  },
  liveResultRight: {
    alignItems: "flex-end",
  },
  liveResultPrice: {
    fontSize: 13,
    fontWeight: "700",
    color: "#E8E0FF",
  },
  liveResultChange: {
    fontSize: 11,
    fontWeight: "600",
  },
});
