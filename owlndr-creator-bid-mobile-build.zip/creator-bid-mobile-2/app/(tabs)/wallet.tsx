import { Text, View, Pressable, ScrollView, Linking, Alert } from "react-native";
import { useState } from "react";
import { ScreenContainer } from "@/components/screen-container";
import { MOCK_TRANSACTIONS } from "@/lib/mock-data";
import { StyleSheet, Platform } from "react-native";
import * as Haptics from "expo-haptics";

interface WalletState {
  connected: boolean;
  address: string;
  eth: number;
  usdc: number;
  bid: number;
}

export default function WalletScreen() {
  const [wallet, setWallet] = useState<WalletState>({
    connected: false,
    address: "",
    eth: 0,
    usdc: 0,
    bid: 0,
  });

  const handleConnectBrave = async () => {
    if (Platform.OS !== "web") {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    }
    // Simulate wallet connection
    // In production, this would use WalletConnect or Brave Wallet deep link
    setWallet({
      connected: true,
      address: "0x7a3B...4f2E",
      eth: 0.847,
      usdc: 12450.32,
      bid: 5280,
    });
  };

  const handleConnectCoinbase = async () => {
    if (Platform.OS !== "web") {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    }
    // In production, this would use Coinbase Wallet SDK / Mobile Wallet Protocol
    setWallet({
      connected: true,
      address: "0x5eB2...9c3D",
      eth: 2.105,
      usdc: 15780.00,
      bid: 7420,
    });
  };

  const handleConnectWalletConnect = async () => {
    if (Platform.OS !== "web") {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    }
    setWallet({
      connected: true,
      address: "0x3c9A...8d1F",
      eth: 1.234,
      usdc: 8920.50,
      bid: 3150,
    });
  };

  const handleDisconnect = () => {
    if (Platform.OS !== "web") {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
    setWallet({ connected: false, address: "", eth: 0, usdc: 0, bid: 0 });
  };

  const handleOpenExplorer = () => {
    Linking.openURL("https://basescan.org");
  };

  if (!wallet.connected) {
    return (
      <ScreenContainer>
        <View style={styles.connectContainer}>
          <View style={styles.connectHeader}>
            <Text style={styles.title}>Connect Wallet</Text>
            <Text style={styles.subtitle}>Connect your wallet to trade AI agents on Base</Text>
          </View>

          {/* Network Info */}
          <View style={styles.networkCard}>
            <View style={styles.networkRow}>
              <View style={styles.networkDot} />
              <Text style={styles.networkName}>Base</Text>
            </View>
            <Text style={styles.networkDetail}>Chain ID: 8453 · L2 on Ethereum</Text>
          </View>

          {/* Brave Wallet Button */}
          <Pressable
            onPress={handleConnectBrave}
            style={({ pressed }) => [styles.connectBtn, styles.braveBtn, pressed && { opacity: 0.8, transform: [{ scale: 0.97 }] }]}
          >
            <Text style={styles.braveIcon}>🦁</Text>
            <View>
              <Text style={styles.connectBtnTitle}>Connect via Brave Wallet</Text>
              <Text style={styles.connectBtnSub}>Native Base chain support</Text>
            </View>
          </Pressable>

          {/* Coinbase Wallet Button */}
          <Pressable
            onPress={handleConnectCoinbase}
            style={({ pressed }) => [styles.connectBtn, styles.coinbaseBtn, pressed && { opacity: 0.8, transform: [{ scale: 0.97 }] }]}
          >
            <Text style={styles.coinbaseIcon}>🔵</Text>
            <View>
              <Text style={styles.connectBtnTitle}>Coinbase Wallet</Text>
              <Text style={styles.connectBtnSub}>Native Base chain · by Coinbase</Text>
            </View>
          </Pressable>

          {/* WalletConnect Button */}
          <Pressable
            onPress={handleConnectWalletConnect}
            style={({ pressed }) => [styles.connectBtn, styles.wcBtn, pressed && { opacity: 0.8, transform: [{ scale: 0.97 }] }]}
          >
            <Text style={styles.wcIcon}>🔗</Text>
            <View>
              <Text style={styles.connectBtnTitle}>WalletConnect</Text>
              <Text style={styles.connectBtnSub}>MetaMask, Rainbow & more</Text>
            </View>
          </Pressable>

          {/* Info */}
          <View style={styles.infoBox}>
            <Text style={styles.infoText}>
              OWLNDR operates on Base (Coinbase L2). Your wallet must be connected to Base network to trade agent keys.
            </Text>
          </View>
        </View>
      </ScreenContainer>
    );
  }

  return (
    <ScreenContainer>
      <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
        {/* Connected Header */}
        <View style={styles.header}>
          <Text style={styles.title}>Wallet</Text>
          <Pressable onPress={handleDisconnect} style={({ pressed }) => [styles.disconnectBtn, pressed && { opacity: 0.7 }]}>
            <Text style={styles.disconnectText}>Disconnect</Text>
          </Pressable>
        </View>

        {/* Address Card */}
        <View style={styles.addressCard}>
          <View style={styles.addressRow}>
            <View style={styles.networkDotSmall} />
            <Text style={styles.networkLabel}>Base</Text>
          </View>
          <Text style={styles.address}>{wallet.address}</Text>
          <Pressable onPress={handleOpenExplorer} style={({ pressed }) => [pressed && { opacity: 0.7 }]}>
            <Text style={styles.explorerLink}>View on BaseScan →</Text>
          </Pressable>
        </View>

        {/* Balances */}
        <View style={styles.balancesSection}>
          <Text style={styles.sectionTitle}>Balances</Text>
          <View style={styles.balanceCard}>
            <View style={styles.balanceRow}>
              <View>
                <Text style={styles.tokenSymbol}>ETH</Text>
                <Text style={styles.tokenName}>Ethereum</Text>
              </View>
              <Text style={styles.balanceAmount}>{wallet.eth.toFixed(4)}</Text>
            </View>
          </View>
          <View style={styles.balanceCard}>
            <View style={styles.balanceRow}>
              <View>
                <Text style={styles.tokenSymbol}>USDC</Text>
                <Text style={styles.tokenName}>USD Coin</Text>
              </View>
              <Text style={styles.balanceAmount}>{wallet.usdc.toLocaleString()}</Text>
            </View>
          </View>
          <View style={styles.balanceCard}>
            <View style={styles.balanceRow}>
              <View>
                <Text style={[styles.tokenSymbol, { color: "#7B2FFF" }]}>BID</Text>
                <Text style={styles.tokenName}>CreatorBid Token</Text>
              </View>
              <Text style={styles.balanceAmount}>{wallet.bid.toLocaleString()}</Text>
            </View>
          </View>
        </View>

        {/* Recent Transactions */}
        <View style={styles.txSection}>
          <Text style={styles.sectionTitle}>Recent Activity</Text>
          {MOCK_TRANSACTIONS.map((tx) => (
            <View key={tx.id} style={styles.txRow}>
              <View style={[styles.txTypeBadge, tx.type === "buy" ? styles.txBuy : styles.txSell]}>
                <Text style={styles.txTypeText}>{tx.type.toUpperCase()}</Text>
              </View>
              <View style={styles.txInfo}>
                <Text style={styles.txAgent}>{tx.agent}</Text>
                <Text style={styles.txTime}>{tx.timestamp}</Text>
              </View>
              <Text style={styles.txAmount}>{tx.amount.toLocaleString()} USDC</Text>
            </View>
          ))}
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  connectContainer: {
    flex: 1,
    paddingHorizontal: 20,
    paddingTop: 40,
  },
  connectHeader: {
    marginBottom: 30,
  },
  title: {
    fontSize: 28,
    fontWeight: "800",
    color: "#E8E0FF",
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 15,
    color: "#8B7FAD",
    lineHeight: 22,
  },
  networkCard: {
    backgroundColor: "#110E2A",
    borderRadius: 12,
    padding: 16,
    marginBottom: 24,
    borderWidth: 1,
    borderColor: "#1E1640",
  },
  networkRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    marginBottom: 6,
  },
  networkDot: {
    width: 10,
    height: 10,
    borderRadius: 5,
    backgroundColor: "#0052FF",
  },
  networkName: {
    fontSize: 16,
    fontWeight: "700",
    color: "#E8E0FF",
  },
  networkDetail: {
    fontSize: 13,
    color: "#8B7FAD",
  },
  connectBtn: {
    flexDirection: "row",
    alignItems: "center",
    gap: 14,
    padding: 18,
    borderRadius: 14,
    marginBottom: 12,
    borderWidth: 1,
  },
  braveBtn: {
    backgroundColor: "#1A0E30",
    borderColor: "#FB542B44",
  },
  coinbaseBtn: {
    backgroundColor: "#0A1A3A",
    borderColor: "#0052FF44",
  },
  wcBtn: {
    backgroundColor: "#110E2A",
    borderColor: "#1E1640",
  },
  coinbaseIcon: {
    fontSize: 28,
  },
  braveIcon: {
    fontSize: 28,
  },
  wcIcon: {
    fontSize: 28,
  },
  connectBtnTitle: {
    fontSize: 16,
    fontWeight: "700",
    color: "#E8E0FF",
    marginBottom: 2,
  },
  connectBtnSub: {
    fontSize: 12,
    color: "#8B7FAD",
  },
  infoBox: {
    backgroundColor: "#110E2A",
    borderRadius: 12,
    padding: 16,
    marginTop: 20,
    borderWidth: 1,
    borderColor: "#1E1640",
  },
  infoText: {
    fontSize: 13,
    color: "#8B7FAD",
    lineHeight: 20,
  },
  scrollContent: {
    paddingBottom: 30,
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: 20,
    paddingTop: 12,
    paddingBottom: 16,
  },
  disconnectBtn: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 8,
    backgroundColor: "#FF336622",
  },
  disconnectText: {
    fontSize: 12,
    fontWeight: "700",
    color: "#FF3366",
  },
  addressCard: {
    marginHorizontal: 16,
    backgroundColor: "#110E2A",
    borderRadius: 14,
    padding: 18,
    borderWidth: 1,
    borderColor: "#1E1640",
    marginBottom: 24,
  },
  addressRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    marginBottom: 8,
  },
  networkDotSmall: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: "#0052FF",
  },
  networkLabel: {
    fontSize: 12,
    fontWeight: "700",
    color: "#0052FF",
  },
  address: {
    fontSize: 20,
    fontWeight: "800",
    color: "#E8E0FF",
    marginBottom: 8,
    fontFamily: Platform.OS === "ios" ? "Menlo" : "monospace",
  },
  explorerLink: {
    fontSize: 13,
    color: "#7B2FFF",
    fontWeight: "600",
  },
  balancesSection: {
    paddingHorizontal: 16,
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: "700",
    color: "#E8E0FF",
    marginBottom: 12,
  },
  balanceCard: {
    backgroundColor: "#110E2A",
    borderRadius: 12,
    padding: 16,
    marginBottom: 8,
    borderWidth: 1,
    borderColor: "#1E1640",
  },
  balanceRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  tokenSymbol: {
    fontSize: 16,
    fontWeight: "800",
    color: "#E8E0FF",
    marginBottom: 2,
  },
  tokenName: {
    fontSize: 12,
    color: "#8B7FAD",
  },
  balanceAmount: {
    fontSize: 18,
    fontWeight: "700",
    color: "#E8E0FF",
  },
  txSection: {
    paddingHorizontal: 16,
  },
  txRow: {
    flexDirection: "row",
    alignItems: "center",
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: "#1E164030",
  },
  txTypeBadge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 6,
    marginRight: 12,
  },
  txBuy: {
    backgroundColor: "#00D4FF22",
  },
  txSell: {
    backgroundColor: "#FF336622",
  },
  txTypeText: {
    fontSize: 10,
    fontWeight: "800",
    color: "#E8E0FF",
    letterSpacing: 0.5,
  },
  txInfo: {
    flex: 1,
  },
  txAgent: {
    fontSize: 14,
    fontWeight: "700",
    color: "#E8E0FF",
    marginBottom: 2,
  },
  txTime: {
    fontSize: 11,
    color: "#8B7FAD",
  },
  txAmount: {
    fontSize: 13,
    fontWeight: "700",
    color: "#E8E0FF",
  },
});
