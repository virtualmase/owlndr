import { Text, View, Pressable, FlatList, Switch } from "react-native";
import { useRouter } from "expo-router";
import { useState } from "react";
import { ScreenContainer } from "@/components/screen-container";
import { useNotifications, useNotificationPrefs } from "@/lib/notifications-store";
import { StyleSheet, Platform } from "react-native";
import * as Haptics from "expo-haptics";

function NotificationCard({ item, onPress }: { item: any; onPress: () => void }) {
  const typeColors: Record<string, string> = {
    price_alert: "#00D4FF",
    new_agent: "#7B2FFF",
    portfolio: "#C084FC",
    system: "#8B7FAD",
  };
  const typeIcons: Record<string, string> = {
    price_alert: "↗",
    new_agent: "★",
    portfolio: "◎",
    system: "⚙",
  };

  const color = typeColors[item.type] ?? "#8B7FAD";
  const icon = typeIcons[item.type] ?? "•";
  const timeAgo = getTimeAgo(item.timestamp);

  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [
        styles.notifCard,
        !item.read && styles.notifCardUnread,
        pressed && { opacity: 0.7 },
      ]}
    >
      <View style={[styles.notifIcon, { backgroundColor: color + "22" }]}>
        <Text style={[styles.notifIconText, { color }]}>{icon}</Text>
      </View>
      <View style={styles.notifContent}>
        <Text style={styles.notifTitle}>{item.title}</Text>
        <Text style={styles.notifBody}>{item.body}</Text>
        <Text style={styles.notifTime}>{timeAgo}</Text>
      </View>
      {!item.read && <View style={styles.unreadDot} />}
    </Pressable>
  );
}

function getTimeAgo(timestamp: number): string {
  const diff = Date.now() - timestamp;
  const minutes = Math.floor(diff / 60000);
  if (minutes < 1) return "Just now";
  if (minutes < 60) return `${minutes}m ago`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.floor(hours / 24);
  return `${days}d ago`;
}

export default function NotificationsScreen() {
  const router = useRouter();
  const { notifications, unreadCount, markRead, clearAll } = useNotifications();
  const { prefs, updatePrefs } = useNotificationPrefs();
  const [showSettings, setShowSettings] = useState(false);

  return (
    <ScreenContainer>
      {/* Header */}
      <View style={styles.header}>
        <Pressable onPress={() => router.back()} style={({ pressed }) => [pressed && { opacity: 0.7 }]}>
          <Text style={styles.backArrow}>←</Text>
        </Pressable>
        <Text style={styles.headerTitle}>Notifications</Text>
        <Pressable
          onPress={() => setShowSettings(!showSettings)}
          style={({ pressed }) => [pressed && { opacity: 0.7 }]}
        >
          <Text style={styles.settingsIcon}>{showSettings ? "✕" : "⚙"}</Text>
        </Pressable>
      </View>

      {showSettings ? (
        <View style={styles.settingsContainer}>
          <Text style={styles.settingsTitle}>Alert Preferences</Text>

          <View style={styles.settingRow}>
            <View style={styles.settingInfo}>
              <Text style={styles.settingLabel}>Price Alerts</Text>
              <Text style={styles.settingDesc}>Notify when watched agents move {prefs.priceThreshold}%+</Text>
            </View>
            <Switch
              value={prefs.priceAlerts}
              onValueChange={(v) => updatePrefs({ priceAlerts: v })}
              trackColor={{ false: "#1E1640", true: "#7B2FFF44" }}
              thumbColor={prefs.priceAlerts ? "#7B2FFF" : "#8B7FAD"}
            />
          </View>

          <View style={styles.settingRow}>
            <View style={styles.settingInfo}>
              <Text style={styles.settingLabel}>New Agent Launches</Text>
              <Text style={styles.settingDesc}>Get notified when new agents go live</Text>
            </View>
            <Switch
              value={prefs.newAgentLaunches}
              onValueChange={(v) => updatePrefs({ newAgentLaunches: v })}
              trackColor={{ false: "#1E1640", true: "#7B2FFF44" }}
              thumbColor={prefs.newAgentLaunches ? "#7B2FFF" : "#8B7FAD"}
            />
          </View>

          <View style={styles.settingRow}>
            <View style={styles.settingInfo}>
              <Text style={styles.settingLabel}>Portfolio Updates</Text>
              <Text style={styles.settingDesc}>Daily summary of your holdings</Text>
            </View>
            <Switch
              value={prefs.portfolioUpdates}
              onValueChange={(v) => updatePrefs({ portfolioUpdates: v })}
              trackColor={{ false: "#1E1640", true: "#7B2FFF44" }}
              thumbColor={prefs.portfolioUpdates ? "#7B2FFF" : "#8B7FAD"}
            />
          </View>

          <View style={styles.settingRow}>
            <View style={styles.settingInfo}>
              <Text style={styles.settingLabel}>Weekly Digest</Text>
              <Text style={styles.settingDesc}>Top performing agents this week</Text>
            </View>
            <Switch
              value={prefs.weeklyDigest}
              onValueChange={(v) => updatePrefs({ weeklyDigest: v })}
              trackColor={{ false: "#1E1640", true: "#7B2FFF44" }}
              thumbColor={prefs.weeklyDigest ? "#7B2FFF" : "#8B7FAD"}
            />
          </View>

          {/* Threshold Selector */}
          <View style={styles.thresholdSection}>
            <Text style={styles.settingLabel}>Price Alert Threshold</Text>
            <View style={styles.thresholdRow}>
              {[5, 10, 15, 25].map((val) => (
                <Pressable
                  key={val}
                  onPress={() => updatePrefs({ priceThreshold: val })}
                  style={[
                    styles.thresholdBtn,
                    prefs.priceThreshold === val && styles.thresholdBtnActive,
                  ]}
                >
                  <Text
                    style={[
                      styles.thresholdText,
                      prefs.priceThreshold === val && styles.thresholdTextActive,
                    ]}
                  >
                    {val}%
                  </Text>
                </Pressable>
              ))}
            </View>
          </View>
        </View>
      ) : (
        <>
          {/* Unread Count + Clear */}
          {notifications.length > 0 && (
            <View style={styles.subHeader}>
              <Text style={styles.unreadText}>
                {unreadCount > 0 ? `${unreadCount} unread` : "All read"}
              </Text>
              <Pressable onPress={clearAll} style={({ pressed }) => [pressed && { opacity: 0.7 }]}>
                <Text style={styles.clearText}>Clear All</Text>
              </Pressable>
            </View>
          )}

          {/* Notification List */}
          <FlatList
            data={notifications}
            keyExtractor={(item) => item.id}
            renderItem={({ item }) => (
              <NotificationCard
                item={item}
                onPress={() => {
                  markRead(item.id);
                  if (item.agentId) {
                    router.push(`/agent/${item.agentId}`);
                  }
                }}
              />
            )}
            contentContainerStyle={styles.listContent}
            ListEmptyComponent={
              <View style={styles.emptyState}>
                <Text style={styles.emptyIcon}>🔔</Text>
                <Text style={styles.emptyTitle}>No Notifications</Text>
                <Text style={styles.emptyDesc}>
                  Add agents to your watchlist to receive price alerts and updates.
                </Text>
              </View>
            }
          />
        </>
      )}
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: "#1E1640",
  },
  backArrow: {
    fontSize: 22,
    color: "#8B7FAD",
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: "700",
    color: "#E8E0FF",
  },
  settingsIcon: {
    fontSize: 18,
    color: "#8B7FAD",
  },
  subHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: 20,
    paddingVertical: 10,
  },
  unreadText: {
    fontSize: 13,
    fontWeight: "600",
    color: "#8B7FAD",
  },
  clearText: {
    fontSize: 13,
    fontWeight: "600",
    color: "#FF3366",
  },
  listContent: {
    paddingHorizontal: 16,
    paddingBottom: 20,
  },
  notifCard: {
    flexDirection: "row",
    alignItems: "flex-start",
    padding: 14,
    backgroundColor: "#110E2A",
    borderRadius: 12,
    marginBottom: 8,
    borderWidth: 1,
    borderColor: "#1E1640",
  },
  notifCardUnread: {
    borderColor: "#7B2FFF44",
    backgroundColor: "#13102E",
  },
  notifIcon: {
    width: 36,
    height: 36,
    borderRadius: 18,
    alignItems: "center",
    justifyContent: "center",
    marginRight: 12,
  },
  notifIconText: {
    fontSize: 16,
    fontWeight: "700",
  },
  notifContent: {
    flex: 1,
  },
  notifTitle: {
    fontSize: 14,
    fontWeight: "700",
    color: "#E8E0FF",
    marginBottom: 3,
  },
  notifBody: {
    fontSize: 12,
    color: "#8B7FAD",
    lineHeight: 17,
    marginBottom: 4,
  },
  notifTime: {
    fontSize: 11,
    color: "#5A4F7A",
  },
  unreadDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: "#7B2FFF",
    marginTop: 4,
  },
  emptyState: {
    alignItems: "center",
    justifyContent: "center",
    paddingTop: 80,
  },
  emptyIcon: {
    fontSize: 48,
    marginBottom: 16,
  },
  emptyTitle: {
    fontSize: 18,
    fontWeight: "700",
    color: "#E8E0FF",
    marginBottom: 8,
  },
  emptyDesc: {
    fontSize: 14,
    color: "#8B7FAD",
    textAlign: "center",
    paddingHorizontal: 40,
    lineHeight: 20,
  },
  // Settings
  settingsContainer: {
    paddingHorizontal: 20,
    paddingTop: 16,
  },
  settingsTitle: {
    fontSize: 16,
    fontWeight: "700",
    color: "#E8E0FF",
    marginBottom: 20,
  },
  settingRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingVertical: 14,
    borderBottomWidth: 1,
    borderBottomColor: "#1E164030",
  },
  settingInfo: {
    flex: 1,
    marginRight: 16,
  },
  settingLabel: {
    fontSize: 14,
    fontWeight: "600",
    color: "#E8E0FF",
    marginBottom: 3,
  },
  settingDesc: {
    fontSize: 12,
    color: "#8B7FAD",
  },
  thresholdSection: {
    marginTop: 20,
  },
  thresholdRow: {
    flexDirection: "row",
    gap: 8,
    marginTop: 10,
  },
  thresholdBtn: {
    flex: 1,
    paddingVertical: 10,
    alignItems: "center",
    backgroundColor: "#1E1640",
    borderRadius: 8,
  },
  thresholdBtnActive: {
    backgroundColor: "#7B2FFF33",
    borderWidth: 1,
    borderColor: "#7B2FFF",
  },
  thresholdText: {
    fontSize: 13,
    fontWeight: "700",
    color: "#8B7FAD",
  },
  thresholdTextActive: {
    color: "#7B2FFF",
  },
});
