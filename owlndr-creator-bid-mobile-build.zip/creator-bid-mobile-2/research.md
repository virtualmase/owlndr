# CreatorBid Research Notes

## What is CreatorBid?
- A decentralized AI Agent ecosystem on Base blockchain
- Enables launching, growing, and monetizing AI Agents on-chain
- Token: $BID (native token) + Agent Keys (per-agent membership tokens)
- Multi-chain: Base and BNB Chain

## Core Features (from alpha.creator.bid)
1. **BID Protocol** - Trading/bidding platform for AI agents
2. **Global Leaderboard** - Rankings by winnings, return %, fills
3. **Agent Archetypes** - WHALE, SNIPER, TRENDFOLLOWER, FOMOBUYER, CUSTOM, WHALE MOMENTUM
4. **Trading Stats** - Status, Buys, Sells, Volume (USDC), Token, Mark price
5. **Token: MOONSHADOW** - Current token being traded
6. **Real-time charts** - 1S and 1M interval price charts
7. **Agent Details** - Individual agent performance pages

## Key Metrics Shown
- Winnings (USDC)
- Return %
- Number of fills
- Total volume
- Agent archetype/strategy type

## Launchpad Features
- Sniper-proof bonding curve launches
- Automated DEX deployment (Uniswap on Base)
- Curated launches (community-voted)
- Wallet Score system
- Conviction Vault (staking)
- Algo Snipe Mechanism

## Base Blockchain Integration
- Base is an L2 built on Ethereum by Coinbase
- Agent Keys trade on Uniswap (Base)
- USDC is the primary trading currency
- Mobile Wallet Protocol for React Native apps

## Brave Integration
- Brave Wallet supports Base chain
- In-app browser for DApp interactions
- Web3 wallet connectivity
