/**
 * Interactive Price Chart Component
 * Renders line/area charts with timeframe selection
 */
import { View, Text, Pressable, Dimensions } from "react-native";
import { useState, useMemo } from "react";
import { StyleSheet } from "react-native";
import Svg, { Path, Defs, LinearGradient, Stop, Line, Circle } from "react-native-svg";

export type Timeframe = "5M" | "1H" | "6H" | "24H" | "7D";

interface PriceChartProps {
  data: number[];
  color?: string;
  height?: number;
  showTimeframes?: boolean;
  currentPrice?: number;
  priceChange?: number;
}

function generatePath(data: number[], width: number, height: number, padding: number = 8): string {
  if (data.length < 2) return "";
  const min = Math.min(...data);
  const max = Math.max(...data);
  const range = max - min || 1;
  const chartHeight = height - padding * 2;
  const chartWidth = width - padding * 2;
  const stepX = chartWidth / (data.length - 1);

  let path = "";
  data.forEach((point, idx) => {
    const x = padding + idx * stepX;
    const y = padding + chartHeight - ((point - min) / range) * chartHeight;
    if (idx === 0) {
      path += `M ${x} ${y}`;
    } else {
      // Smooth curve using quadratic bezier
      const prevX = padding + (idx - 1) * stepX;
      const prevY = padding + chartHeight - ((data[idx - 1] - min) / range) * chartHeight;
      const cpX = (prevX + x) / 2;
      path += ` Q ${cpX} ${prevY} ${x} ${y}`;
    }
  });
  return path;
}

function generateAreaPath(data: number[], width: number, height: number, padding: number = 8): string {
  if (data.length < 2) return "";
  const linePath = generatePath(data, width, height, padding);
  const chartWidth = width - padding * 2;
  const lastX = padding + chartWidth;
  return `${linePath} L ${lastX} ${height} L ${padding} ${height} Z`;
}

export function PriceChart({
  data,
  color = "#7B2FFF",
  height = 180,
  showTimeframes = true,
  currentPrice,
  priceChange,
}: PriceChartProps) {
  const [selectedTimeframe, setSelectedTimeframe] = useState<Timeframe>("24H");
  const screenWidth = Dimensions.get("window").width - 64; // Account for padding

  // Generate different data views based on timeframe (simulated)
  const chartData = useMemo(() => {
    if (data.length === 0) return [];
    switch (selectedTimeframe) {
      case "5M":
        return data.slice(-5);
      case "1H":
        return data.slice(-12);
      case "6H":
        return data.slice(-18);
      case "24H":
        return data;
      case "7D":
        // Simulate 7D by repeating and adding variation
        return [...data, ...data.map((d) => d * (0.95 + Math.random() * 0.1))];
      default:
        return data;
    }
  }, [data, selectedTimeframe]);

  const linePath = generatePath(chartData, screenWidth, height);
  const areaPath = generateAreaPath(chartData, screenWidth, height);
  const isPositive = (priceChange ?? 0) >= 0;
  const chartColor = isPositive ? "#00D4FF" : "#FF3366";

  return (
    <View style={styles.container}>
      {/* Price Header */}
      {currentPrice !== undefined && (
        <View style={styles.priceHeader}>
          <Text style={styles.priceText}>${currentPrice.toFixed(6)}</Text>
          {priceChange !== undefined && (
            <View style={[styles.changeBadge, { backgroundColor: isPositive ? "#00D4FF22" : "#FF336622" }]}>
              <Text style={[styles.changeText, { color: chartColor }]}>
                {isPositive ? "+" : ""}{priceChange.toFixed(2)}%
              </Text>
            </View>
          )}
        </View>
      )}

      {/* SVG Chart */}
      <View style={[styles.chartWrapper, { height }]}>
        {chartData.length > 1 ? (
          <Svg width={screenWidth} height={height}>
            <Defs>
              <LinearGradient id="areaGradient" x1="0" y1="0" x2="0" y2="1">
                <Stop offset="0" stopColor={chartColor} stopOpacity="0.3" />
                <Stop offset="1" stopColor={chartColor} stopOpacity="0.02" />
              </LinearGradient>
            </Defs>
            {/* Area fill */}
            <Path d={areaPath} fill="url(#areaGradient)" />
            {/* Line */}
            <Path d={linePath} stroke={chartColor} strokeWidth={2} fill="none" strokeLinecap="round" />
            {/* Current price dot */}
            {chartData.length > 0 && (() => {
              const min = Math.min(...chartData);
              const max = Math.max(...chartData);
              const range = max - min || 1;
              const lastIdx = chartData.length - 1;
              const stepX = (screenWidth - 16) / (chartData.length - 1);
              const x = 8 + lastIdx * stepX;
              const y = 8 + (height - 16) - ((chartData[lastIdx] - min) / range) * (height - 16);
              return (
                <>
                  <Circle cx={x} cy={y} r={4} fill={chartColor} />
                  <Circle cx={x} cy={y} r={7} fill={chartColor} opacity={0.3} />
                </>
              );
            })()}
          </Svg>
        ) : (
          <View style={styles.noData}>
            <Text style={styles.noDataText}>No chart data</Text>
          </View>
        )}
      </View>

      {/* Timeframe Selector */}
      {showTimeframes && (
        <View style={styles.timeframeRow}>
          {(["5M", "1H", "6H", "24H", "7D"] as Timeframe[]).map((tf) => (
            <Pressable
              key={tf}
              onPress={() => setSelectedTimeframe(tf)}
              style={[
                styles.tfBtn,
                selectedTimeframe === tf && styles.tfBtnActive,
              ]}
            >
              <Text
                style={[
                  styles.tfText,
                  selectedTimeframe === tf && styles.tfTextActive,
                ]}
              >
                {tf}
              </Text>
            </Pressable>
          ))}
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    width: "100%",
  },
  priceHeader: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    marginBottom: 12,
  },
  priceText: {
    fontSize: 22,
    fontWeight: "800",
    color: "#E8E0FF",
  },
  changeBadge: {
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 6,
  },
  changeText: {
    fontSize: 13,
    fontWeight: "700",
  },
  chartWrapper: {
    width: "100%",
    overflow: "hidden",
  },
  noData: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  noDataText: {
    fontSize: 13,
    color: "#8B7FAD",
  },
  timeframeRow: {
    flexDirection: "row",
    justifyContent: "center",
    gap: 6,
    marginTop: 12,
  },
  tfBtn: {
    paddingHorizontal: 14,
    paddingVertical: 6,
    borderRadius: 8,
    backgroundColor: "#1E1640",
  },
  tfBtnActive: {
    backgroundColor: "#7B2FFF33",
    borderWidth: 1,
    borderColor: "#7B2FFF",
  },
  tfText: {
    fontSize: 12,
    fontWeight: "700",
    color: "#8B7FAD",
  },
  tfTextActive: {
    color: "#7B2FFF",
  },
});
