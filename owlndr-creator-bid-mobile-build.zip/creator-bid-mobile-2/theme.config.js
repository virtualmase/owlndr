/** @type {const} */
const themeColors = {
  primary: { light: '#7B2FFF', dark: '#7B2FFF' },
  background: { light: '#08061A', dark: '#08061A' },
  surface: { light: '#110E2A', dark: '#110E2A' },
  foreground: { light: '#E8E0FF', dark: '#E8E0FF' },
  muted: { light: '#8B7FAD', dark: '#8B7FAD' },
  border: { light: '#1E1640', dark: '#1E1640' },
  success: { light: '#00D4FF', dark: '#00D4FF' },
  warning: { light: '#C084FC', dark: '#C084FC' },
  error: { light: '#FF3366', dark: '#FF3366' },
};

module.exports = { themeColors };
