/**
 * React Query hooks for live data fetching
 */
import { useQuery } from "@tanstack/react-query";
import {
  fetchBIDPairData,
  fetchPairData,
  fetchProtocolStats,
  fetchAgentTokens,
  searchTokenPairs,
  type TokenPairData,
  type ProtocolLiveStats,
  type AgentLiveData,
} from "@/lib/api";

/**
 * Hook for BID token pair data (price, volume, liquidity)
 */
export function useBIDPairData() {
  return useQuery<TokenPairData | null>({
    queryKey: ["bid-pair-data"],
    queryFn: fetchBIDPairData,
    staleTime: 30_000, // 30s
    refetchInterval: 30_000, // Auto-refresh every 30s
    retry: 2,
  });
}

/**
 * Hook for one live pair detail page
 */
export function usePairData(pairAddress: string, enabled = true) {
  return useQuery<TokenPairData | null>({
    queryKey: ["pair-data", pairAddress],
    queryFn: () => fetchPairData(pairAddress),
    enabled: enabled && pairAddress.length > 0,
    staleTime: 30_000,
    refetchInterval: 30_000,
    retry: 1,
  });
}

/**
 * Hook for protocol-level stats
 */
export function useProtocolStats() {
  return useQuery<ProtocolLiveStats | null>({
    queryKey: ["protocol-stats"],
    queryFn: fetchProtocolStats,
    staleTime: 30_000,
    refetchInterval: 30_000,
    retry: 2,
  });
}

/**
 * Hook for agent token listings
 */
export function useAgentTokens() {
  return useQuery<AgentLiveData[]>({
    queryKey: ["agent-tokens"],
    queryFn: fetchAgentTokens,
    staleTime: 60_000, // 1 min
    refetchInterval: 60_000,
    retry: 2,
  });
}

/**
 * Hook for searching token pairs
 */
export function useSearchPairs(query: string) {
  return useQuery<TokenPairData[]>({
    queryKey: ["search-pairs", query],
    queryFn: () => searchTokenPairs(query),
    enabled: query.length > 1,
    staleTime: 30_000,
    retry: 1,
  });
}
